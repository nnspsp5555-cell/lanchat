package com.example.lanchat

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.concurrent.thread

data class ChatMessage(
    val id: String,
    val name: String,
    val text: String,
    val time: Long,
    val mine: Boolean
)

/**
 * شبكة الدردشة: بدون سيرفر. كل جهاز يرسل الرسائل بـ UDP Broadcast على الشبكة المحلية
 * ويستمع على نفس المنفذ، وكل جهاز يعلن عن نفسه كل 4 ثواني ليظهر في قائمة المتصلين.
 */
data class Peer(val id: String, val name: String, val ip: String, val seen: Long)

object ChatNet {
    const val PORT = 45454
    const val MAX_LEN = 500
    private const val PEER_TIMEOUT = 15_000L

    val deviceId = UUID.randomUUID().toString().take(8)
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var myName: String = ""

    // تُقرأ وتُعدَّل على الخيط الرئيسي فقط
    val messages = ArrayList<ChatMessage>()
    private val seen = HashSet<String>()

    private val peers = ConcurrentHashMap<String, Peer>()

    var onMessage: ((ChatMessage) -> Unit)? = null
    var onIncoming: ((ChatMessage) -> Unit)? = null   // رسالة واردة من غيري (للإشعارات)

    @Volatile
    var appVisible: Boolean = false
    var onPeers: ((List<String>) -> Unit)? = null
    var onStatus: ((String?) -> Unit)? = null

    @Volatile
    private var socket: DatagramSocket? = null
    private var lock: WifiManager.MulticastLock? = null
    private var sender = Executors.newSingleThreadExecutor()

    @Volatile
    private var running = false

    @Synchronized
    fun start(ctx: Context) {
        if (running) return
        running = true
        try {
            val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            lock = wifi.createMulticastLock("lanchat").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {
        }
        sender = Executors.newSingleThreadExecutor()
        thread(name = "lanchat-rx", isDaemon = true) { receiveLoop() }
        thread(name = "lanchat-hb", isDaemon = true) { heartbeatLoop() }
    }

    @Synchronized
    fun stop() {
        running = false
        try {
            socket?.close()
        } catch (_: Exception) {
        }
        socket = null
        try {
            lock?.release()
        } catch (_: Exception) {
        }
        lock = null
        sender.shutdownNow()
        peers.clear()
    }

    /** يُستدعى من الخيط الرئيسي */
    fun send(text: String) {
        val t = text.trim().take(MAX_LEN)
        if (t.isEmpty() || myName.isEmpty()) return
        val now = System.currentTimeMillis()
        val id = "$deviceId-$now-${(0..9999).random()}"
        val m = ChatMessage(id, myName, t, now, true)
        seen.add(id)
        messages.add(m)
        onMessage?.invoke(m)

        val json = JSONObject()
            .put("t", "msg").put("d", deviceId).put("i", id)
            .put("n", myName).put("x", t).put("ts", now)
            .toString()
        sendRaw(json, 2) // مرتين لتقليل ضياع الحزم، والتكرار يُحذف بالـ id
    }

    private fun sendRaw(json: String, times: Int) {
        val bytes = json.toByteArray(Charsets.UTF_8)
        try {
            sender.execute {
                repeat(times) { n ->
                    val s = socket
                    if (s != null) {
                        for (addr in targets()) {
                            try {
                                s.send(DatagramPacket(bytes, bytes.size, addr, PORT))
                            } catch (_: Exception) {
                            }
                        }
                    }
                    if (n < times - 1) nap(150)
                }
            }
        } catch (_: Exception) {
        }
    }

    /** قائمة المتصلين حالياً (مع عناوينهم) */
    fun peerList(): List<Peer> {
        val now = System.currentTimeMillis()
        return peers.values.filter { now - it.seen <= PEER_TIMEOUT }.sortedBy { it.name }
    }

    /** إرسال رسالة تحكم لجهاز واحد بالعنوان المباشر (للمكالمات) */
    fun sendTo(ip: String, json: String, times: Int) {
        val bytes = json.toByteArray(Charsets.UTF_8)
        try {
            sender.execute {
                val addr = try {
                    InetAddress.getByName(ip)
                } catch (_: Exception) {
                    null
                }
                if (addr == null) return@execute
                repeat(times) { n ->
                    try {
                        socket?.send(DatagramPacket(bytes, bytes.size, addr, PORT))
                    } catch (_: Exception) {
                    }
                    if (n < times - 1) nap(150)
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun targets(): Set<InetAddress> {
        val out = LinkedHashSet<InetAddress>()
        try {
            NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { ni ->
                if (ni.isUp && !ni.isLoopback) {
                    ni.interfaceAddresses.forEach { ia -> ia.broadcast?.let { out.add(it) } }
                }
            }
        } catch (_: Exception) {
        }
        try {
            out.add(InetAddress.getByName("255.255.255.255"))
        } catch (_: Exception) {
        }
        return out
    }

    private fun receiveLoop() {
        val buf = ByteArray(4096)
        while (running) {
            var s = socket
            if (s == null || s.isClosed) {
                try {
                    s = DatagramSocket(null).apply {
                        reuseAddress = true
                        broadcast = true
                        bind(InetSocketAddress(PORT))
                    }
                    socket = s
                    main.post { onStatus?.invoke(null) }
                } catch (_: Exception) {
                    main.post { onStatus?.invoke("تعذّر فتح المنفذ، تأكد من الاتصال بالواي فاي") }
                    nap(3000)
                    continue
                }
            }
            try {
                val p = DatagramPacket(buf, buf.size)
                s!!.receive(p)
                handle(String(p.data, 0, p.length, Charsets.UTF_8), p.address?.hostAddress ?: "")
            } catch (_: Exception) {
                if (running) nap(300)
            }
        }
    }

    private fun handle(raw: String, ip: String) {
        val o = try {
            JSONObject(raw)
        } catch (_: Exception) {
            return
        }
        val d = o.optString("d")
        if (d.isEmpty() || d == deviceId) return // تجاهل رسائلي أنا
        val n = o.optString("n").take(24)
        if (n.isNotEmpty() && ip.isNotEmpty()) peers[d] = Peer(d, n, ip, System.currentTimeMillis())

        when (o.optString("t")) {
            "msg" -> {
                val id = o.optString("i")
                val x = o.optString("x").take(MAX_LEN)
                if (id.isNotEmpty() && x.isNotEmpty() && n.isNotEmpty()) {
                    val ts = o.optLong("ts", System.currentTimeMillis())
                    main.post {
                        if (seen.add(id)) {
                            val m = ChatMessage(id, n, x, ts, false)
                            messages.add(m)
                            onMessage?.invoke(m)
                            onIncoming?.invoke(m)
                        }
                    }
                }
            }
            "call", "acc", "end", "busy" -> {
                val c = o.optString("c")
                val t = o.optString("t")
                if (c.isNotEmpty()) main.post { CallManager.onSignal(t, c, d, n, ip) }
            }
        }
        publishPeers()
    }

    private fun publishPeers() {
        val now = System.currentTimeMillis()
        peers.entries.removeIf { now - it.value.seen > PEER_TIMEOUT }
        val names = peers.values.map { it.name }.distinct().sorted()
        main.post { onPeers?.invoke(names) }
    }

    private fun heartbeatLoop() {
        while (running) {
            if (myName.isNotEmpty()) {
                val hello = JSONObject().put("t", "hello").put("d", deviceId).put("n", myName).toString()
                sendRaw(hello, 1)
            }
            publishPeers()
            nap(4000)
        }
    }

    private fun nap(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }
}
