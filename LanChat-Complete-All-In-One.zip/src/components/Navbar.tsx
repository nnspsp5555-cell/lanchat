import {
  Wifi,
  WifiOff,
  Settings,
  QrCode,
  Zap,
  Users,
  Search,
  RefreshCw,
  Download,
} from 'lucide-react';
import { AccentColor } from '../types/chat';

interface NavbarProps {
  isConnected: boolean;
  onlineCount: number;
  onOpenNetworkModal: () => void;
  onOpenSettingsModal: () => void;
  onOpenInstallModal: () => void;
  onToggleMobileDrawer: () => void;
  onSendNudge: () => void;
  onToggleSearch: () => void;
  isSearching: boolean;
  unreadTotal: number;
  accent: AccentColor;
}

export const Navbar: React.FC<NavbarProps> = ({
  isConnected,
  onlineCount,
  onOpenNetworkModal,
  onOpenSettingsModal,
  onOpenInstallModal,
  onToggleMobileDrawer,
  onSendNudge,
  onToggleSearch,
  isSearching,
  unreadTotal,
  accent,
}) => {
  return (
    <header className="h-14 bg-slate-950/90 border-b border-slate-800 backdrop-blur-md px-3 sm:px-4 flex items-center justify-between select-none z-30 shrink-0">
      {/* Right side (RTL Start): Logo & Status */}
      <div className="flex items-center gap-2.5 sm:gap-3">
        {/* Mobile menu trigger for peers list */}
        <button
          onClick={onToggleMobileDrawer}
          className="relative lg:hidden p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-400 transition-colors cursor-pointer"
          title="قائمة الأجهزة المتصلة"
        >
          <Users size={18} />
          {unreadTotal > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-cyan-500 text-slate-950 text-[10px] font-bold flex items-center justify-center">
              {unreadTotal}
            </span>
          )}
        </button>

        {/* Brand identity */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-500 flex items-center justify-center text-white shadow-md shadow-cyan-950">
            <Wifi size={18} className="animate-pulse" />
          </div>
          <div>
            <h1 className="font-extrabold text-sm sm:text-base tracking-tight text-white flex items-center gap-1.5">
              <span>الدردشة بدون إنترنت</span>
            </h1>
            <div className="flex items-center gap-1.5 text-[10px]">
              <span
                className={`inline-block w-1.5 h-1.5 rounded-full ${
                  isConnected ? 'bg-emerald-400 shadow-[0_0_8px_#34d399]' : 'bg-rose-500'
                }`}
              />
              <span className="text-slate-400">
                {isConnected ? `متصل محلياً (${onlineCount} جهاز)` : 'انقطع الاتصال بالخادم'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Left side (RTL End): Actions */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Search in chat */}
        <button
          onClick={onToggleSearch}
          className={`p-2 rounded-xl transition-all cursor-pointer ${
            isSearching
              ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
          title="بحث في المحادثة"
        >
          <Search size={18} />
        </button>

        {/* Buzz / Nudge button */}
        <button
          onClick={onSendNudge}
          className="p-2 rounded-xl text-slate-400 hover:text-amber-400 hover:bg-slate-900 transition-colors cursor-pointer"
          title="إرسال تنبيه واهتزاز (نكز)"
        >
          <Zap size={18} />
        </button>

        {/* Install on phone button */}
        <button
          onClick={onOpenInstallModal}
          className="flex items-center gap-1.5 py-1.5 px-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md shadow-emerald-950 cursor-pointer"
          title="تثبيت التطبيق على جهازك مباشرة"
        >
          <Download size={15} />
          <span>تثبيت</span>
        </button>

        {/* Wi-Fi & QR code button */}
        <button
          onClick={onOpenNetworkModal}
          className="flex items-center gap-1.5 py-1.5 px-2.5 rounded-xl bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-700/50 text-cyan-300 text-xs font-semibold transition-all shadow-sm cursor-pointer"
          title="معلومات ربط Wi-Fi ورمز QR"
        >
          <QrCode size={16} />
          <span className="hidden sm:inline">ربط الأجهزة (QR)</span>
        </button>

        {/* Settings button */}
        <button
          onClick={onOpenSettingsModal}
          className="p-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-900 transition-colors cursor-pointer"
          title="الإعدادات والمظهر"
        >
          <Settings size={18} />
        </button>
      </div>
    </header>
  );
};
