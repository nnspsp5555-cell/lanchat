package com.example.lanchat

import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.Camera
import kotlin.math.abs

/** كاميرا المكالمة (واجهة Camera القديمة: بسيطة وتشتغل على كل الأندرويدات) */
@Suppress("DEPRECATION")
class VideoCam {
    private var cam: Camera? = null

    var front = true

    fun start(st: SurfaceTexture): Boolean {
        stop()
        try {
            val n = Camera.getNumberOfCameras()
            if (n == 0) return false
            val info = Camera.CameraInfo()
            var id = -1
            val wanted = if (front) Camera.CameraInfo.CAMERA_FACING_FRONT else Camera.CameraInfo.CAMERA_FACING_BACK
            for (i in 0 until n) {
                Camera.getCameraInfo(i, info)
                if (info.facing == wanted) {
                    id = i
                    break
                }
            }
            if (id < 0) {
                id = 0
                Camera.getCameraInfo(0, info)
                front = info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT
            }
            val c = Camera.open(id)
            val p = c.parameters
            val size = p.supportedPreviewSizes.minByOrNull { abs(it.width - 320) + abs(it.height - 240) }
                ?: return false
            p.setPreviewSize(size.width, size.height)
            p.previewFormat = ImageFormat.NV21
            c.parameters = p
            // الشاشة عمودية دائماً
            val display = if (front) (360 - info.orientation % 360) % 360 else (info.orientation + 360) % 360
            c.setDisplayOrientation(display)
            c.setPreviewTexture(st)
            val w = size.width
            val h = size.height
            val rot = info.orientation
            c.setPreviewCallback { data, _ -> CallManager.sendVideoFrame(data, w, h, rot) }
            c.startPreview()
            cam = c
            return true
        } catch (_: Exception) {
            stop()
            return false
        }
    }

    fun stop() {
        val c = cam ?: return
        cam = null
        try {
            c.setPreviewCallback(null)
            c.stopPreview()
        } catch (_: Exception) {
        }
        try {
            c.release()
        } catch (_: Exception) {
        }
    }
}
