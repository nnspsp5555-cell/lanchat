package com.example.lanchat

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import java.io.DataInputStream
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/**
 * وصلة بلوتوث بين جهازين. الإطار: [نوع:1 بايت][الطول:2 بايت][المحتوى]
 * النوع 1 = رسالة تحكم (JSON)، النوع 2 = صوت.
 */
class BtLink(private val sock: BluetoothSocket) {
    private val out = sock.outputStream
    private val inp = DataInputStream(sock.inputStream)
    private val lock = Any()
    private val ex = Executors.newSingleThreadExecutor()

    @Volatile
    var alive = true

    @Volatile
    var claimed = false

    fun write(type: Int, payload: ByteArray, len: Int = payload.size): Boolean {
        if (!alive) return false
        return try {
            val b = ByteArray(3 + len)
            b[0] = type.toByte()
            b[1] = (len shr 8).toByte()
            b[2] = len.toByte()
            System.arraycopy(payload, 0, b, 3, len)
            synchronized(lock) {
                out.write(b)
                out.flush()
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun sendSignal(json: String) {
        try {
            ex.execute { write(1, json.toByteArray(Charsets.UTF_8)) }
        } catch (_: Exception) {
        }
    }

    /** يغلق بعد ما تنرسل الرسائل المنتظرة (مثل "إنهاء") */
    fun closeLater() {
        try {
            ex.execute {
                try {
                    Thread.sleep(300)
                } catch (_: InterruptedException) {
                }
                closeNow()
            }
            ex.shutdown()
        } catch (_: Exception) {
            closeNow()
        }
    }

    fun closeNow() {
        alive = false
        try {
            sock.close()
        } catch (_: Exception) {
        }
    }

    fun readLoop(onSignal: (String) -> Unit, onAudio: (ByteArray) -> Unit, onClosed: () -> Unit) {
        try {
            val hdr = ByteArray(3)
            while (alive) {
                inp.readFully(hdr)
                val len = ((hdr[1].toInt() and 0xFF) shl 8) or (hdr[2].toInt() and 0xFF)
                val payload = ByteArray(len)
                inp.readFully(payload)
                when (hdr[0].toInt()) {
                    1 -> onSignal(String(payload, Charsets.UTF_8))
                    2 -> onAudio(payload)
                }
            }
        } catch (_: Exception) {
        }
        closeNow()
        onClosed()
    }
}

/** يستقبل اتصالات البلوتوث الواردة (يشتغل داخل الخدمة) */
object BtServer {
    val APP_UUID: UUID = UUID.fromString("5b7c2f0e-8f3a-4c1d-9a61-3e2d7f4b6a10")
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var running = false

    @Volatile
    private var server: BluetoothServerSocket? = null

    fun hasPerm(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED

    fun adapter(ctx: Context): BluetoothAdapter? = try {
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    } catch (_: Exception) {
        null
    }

    @SuppressLint("MissingPermission")
    @Synchronized
    fun start(ctx: Context) {
        if (running || !hasPerm(ctx)) return
        val ad = adapter(ctx.applicationContext) ?: return
        running = true
        thread(name = "lanchat-bt", isDaemon = true) {
            while (running) {
                try {
                    if (!ad.isEnabled) {
                        nap(3000)
                        continue
                    }
                    val ss = ad.listenUsingInsecureRfcommWithServiceRecord("LanChat", APP_UUID)
                    server = ss
                    while (running) {
                        val s = ss.accept()
                        onAccepted(s)
                    }
                } catch (_: Exception) {
                    nap(2000)
                } finally {
                    try {
                        server?.close()
                    } catch (_: Exception) {
                    }
                    server = null
                }
            }
        }
    }

    @Synchronized
    fun stop() {
        running = false
        try {
            server?.close()
        } catch (_: Exception) {
        }
    }

    private fun onAccepted(s: BluetoothSocket) {
        val link = BtLink(s)
        thread(name = "bt-read", isDaemon = true) {
            link.readLoop(
                { json -> main.post { CallManager.onBtSignal(link, json) } },
                { b -> CallManager.onBtAudio(b) },
                { main.post { CallManager.onBtClosed(link) } }
            )
        }
        // اتصال ما صار منه مكالمة خلال 20 ثانية نغلقه
        main.postDelayed({ if (!link.claimed) link.closeNow() }, 20_000)
    }

    private fun nap(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }
}
