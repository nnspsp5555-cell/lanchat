import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  User,
  ChatMessage,
  ThemeSettings,
  NetworkInfo,
  ReplyContext,
} from './types/chat';
import {
  getStoredUser,
  saveStoredUser,
  getStoredSettings,
  saveStoredSettings,
  getStoredPublicMessages,
  saveStoredPublicMessages,
  getStoredPrivateMessages,
  saveStoredPrivateMessages,
} from './utils/storage';
import { detectDeviceType } from './utils/media';
import { sound } from './utils/sound';
import { Navbar } from './components/Navbar';
import { PeersList } from './components/PeersList';
import { ChatArea } from './components/ChatArea';
import { NetworkModal } from './components/NetworkModal';
import { SettingsModal } from './components/SettingsModal';
import { MediaLightbox } from './components/MediaLightbox';
import { InstallModal } from './components/InstallModal';

export default function App() {
  // User state
  const [currentUser, setCurrentUser] = useState<User>(() => {
    const saved = getStoredUser();
    const devType = detectDeviceType();
    const defaultAvatars = ['⚡', '🤖', '🚀', '🌟', '🦁', '🔥'];
    const randomAvatar = defaultAvatars[Math.floor(Math.random() * defaultAvatars.length)];

    return {
      id: saved?.id || `user_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: saved?.name || (devType === 'android' ? 'مستخدم أندرويد' : 'مستخدم محلي'),
      avatar: saved?.avatar || randomAvatar,
      deviceType: saved?.deviceType || devType,
      status: saved?.status || 'online',
      joinedAt: saved?.joinedAt || Date.now(),
    };
  });

  // Settings & Theme
  const [settings, setSettings] = useState<ThemeSettings>(getStoredSettings);

  // Connection & Peers
  const [isConnected, setIsConnected] = useState(false);
  const [peers, setPeers] = useState<User[]>([]);
  const [activeChatId, setActiveChatId] = useState<string>('public'); // 'public' or userId
  const [networkInfo, setNetworkInfo] = useState<NetworkInfo | null>(null);

  // Messages
  const [publicMessages, setPublicMessages] = useState<ChatMessage[]>(getStoredPublicMessages);
  const [privateMessages, setPrivateMessages] = useState<Record<string, ChatMessage[]>>(
    getStoredPrivateMessages
  );
  const [unreadCounts, setUnreadCounts] = useState<Record<string, number>>({});

  // Typing state
  const [typingUsers, setTypingUsers] = useState<{ id: string; name: string }[]>([]);

  // Modals & Drawers
  const [isNetworkModalOpen, setIsNetworkModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<{ url: string; fileName?: string } | null>(
    null
  );
  const [isShaking, setIsShaking] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  // Capture PWA install prompt event
  useEffect(() => {
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
  }, []);

  const handleInstallNative = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setDeferredPrompt(null);
        setIsInstallModalOpen(false);
      }
    }
  };

  // WebSocket ref
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<any>(null);
  const pingIntervalRef = useRef<any>(null);

  // Fetch local network info from Express API
  const fetchNetworkInfo = async () => {
    try {
      const res = await fetch('/api/network-info');
      if (res.ok) {
        const data = await res.json();
        setNetworkInfo(data);
        if (data.clientIp) {
          setCurrentUser((prev) => ({ ...prev, ip: data.clientIp }));
        }
      }
    } catch (err) {
      console.warn('Network info endpoint unreachable:', err);
    }
  };

  useEffect(() => {
    fetchNetworkInfo();
  }, []);

  // Save changes to storage
  useEffect(() => {
    saveStoredUser(currentUser);
  }, [currentUser]);

  useEffect(() => {
    saveStoredSettings(settings);
  }, [settings]);

  useEffect(() => {
    saveStoredPublicMessages(publicMessages);
  }, [publicMessages]);

  useEffect(() => {
    saveStoredPrivateMessages(privateMessages);
  }, [privateMessages]);

  // Connect WebSocket
  useEffect(() => {
    let isMounted = true;

    function connectWs() {
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) return;

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}`;

      try {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          if (!isMounted) return;
          setIsConnected(true);

          // Register client with server
          ws.send(
            JSON.stringify({
              type: 'register',
              user: currentUser,
            })
          );

          // Setup ping heartbeat
          if (pingIntervalRef.current) clearInterval(pingIntervalRef.current);
          pingIntervalRef.current = setInterval(() => {
            if (ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({ type: 'ping' }));
            }
          }, 25000);
        };

        ws.onmessage = (event) => {
          if (!isMounted) return;
          try {
            const data = JSON.parse(event.data);

            switch (data.type) {
              case 'registered': {
                if (data.self) {
                  setCurrentUser((prev) => ({ ...prev, id: data.self.id, ip: data.self.ip }));
                }
                if (Array.isArray(data.users)) {
                  setPeers(data.users);
                }
                if (Array.isArray(data.recentMessages) && data.recentMessages.length > 0) {
                  // Merge recent messages idempotently
                  setPublicMessages((prev) => {
                    const existingIds = new Set(prev.map((m) => m.id));
                    const newOnes = data.recentMessages.filter(
                      (m: ChatMessage) => !existingIds.has(m.id)
                    );
                    return [...prev, ...newOnes];
                  });
                }
                break;
              }

              case 'users_list': {
                if (Array.isArray(data.users)) {
                  setPeers(data.users);
                }
                break;
              }

              case 'new_message': {
                const msg: ChatMessage = data.message;
                const isSelf = msg.senderId === currentUser.id;

                if (msg.recipientId === 'public') {
                  // Public message
                  setPublicMessages((prev) => {
                    if (prev.some((m) => m.id === msg.id)) return prev;
                    return [...prev, msg];
                  });

                  if (!isSelf) {
                    if (settings.soundEnabled) sound.playReceive();
                    if (settings.vibrationEnabled) sound.vibrate(80);

                    // Increment unread if not on public chat
                    setActiveChatId((current) => {
                      if (current !== 'public') {
                        setUnreadCounts((counts) => ({
                          ...counts,
                          public: (counts['public'] || 0) + 1,
                        }));
                      }
                      return current;
                    });
                  }
                } else {
                  // Private message
                  const peerKey = isSelf ? msg.recipientId : msg.senderId;
                  setPrivateMessages((prev) => {
                    const list = prev[peerKey] || [];
                    if (list.some((m) => m.id === msg.id)) return prev;
                    return {
                      ...prev,
                      [peerKey]: [...list, msg],
                    };
                  });

                  if (!isSelf) {
                    if (settings.soundEnabled) sound.playReceive();
                    if (settings.vibrationEnabled) sound.vibrate([100, 50, 100]);

                    setActiveChatId((current) => {
                      if (current !== peerKey) {
                        setUnreadCounts((counts) => ({
                          ...counts,
                          [peerKey]: (counts[peerKey] || 0) + 1,
                        }));
                      }
                      return current;
                    });
                  }
                }
                break;
              }

              case 'user_typing': {
                if (data.senderId === currentUser.id) return;
                const matchesRoom =
                  (data.recipientId === 'public' && activeChatId === 'public') ||
                  (data.recipientId === currentUser.id && activeChatId === data.senderId);

                if (matchesRoom) {
                  if (data.isTyping) {
                    setTypingUsers((prev) => {
                      if (prev.some((u) => u.id === data.senderId)) return prev;
                      return [...prev, { id: data.senderId, name: data.senderName }];
                    });
                  } else {
                    setTypingUsers((prev) => prev.filter((u) => u.id !== data.senderId));
                  }
                }
                break;
              }

              case 'nudge_alert': {
                // Buzz alert
                if (settings.soundEnabled) sound.playNudge();
                if (settings.vibrationEnabled) sound.vibrate([200, 100, 200, 100, 300]);

                setIsShaking(true);
                setTimeout(() => setIsShaking(false), 1200);
                break;
              }
            }
          } catch (err) {
            console.error('Error parsing WS message:', err);
          }
        };

        ws.onclose = () => {
          if (!isMounted) return;
          setIsConnected(false);
          if (pingIntervalRef.current) clearInterval(pingIntervalRef.current);

          // Retry connection in 3 seconds
          if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
          reconnectTimeoutRef.current = setTimeout(connectWs, 3000);
        };

        ws.onerror = (e) => {
          console.warn('WebSocket error, waiting for retry:', e);
          ws.close();
        };
      } catch (e) {
        console.error('Error initializing WebSocket:', e);
        if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = setTimeout(connectWs, 3000);
      }
    }

    connectWs();

    return () => {
      isMounted = false;
      if (pingIntervalRef.current) clearInterval(pingIntervalRef.current);
      if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [currentUser.id]);

  // Handle switching chats
  const handleSelectChat = (chatId: string) => {
    setActiveChatId(chatId);
    setTypingUsers([]);
    // Clear unread count for this chat
    setUnreadCounts((prev) => {
      const next = { ...prev };
      delete next[chatId];
      return next;
    });
  };

  // Send message
  const handleSendMessage = ({
    content,
    mediaType = 'text',
    fileUrl,
    fileName,
    fileSize,
    fileMime,
  }: {
    content: string;
    mediaType?: 'text' | 'image' | 'video' | 'audio' | 'file';
    fileUrl?: string;
    fileName?: string;
    fileSize?: number;
    fileMime?: string;
  }) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      alert('غير متصل بالخادم المحلي حالياً. يرجى الانتظار لإعادة الاتصال.');
      return;
    }

    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      recipientId: activeChatId,
      content,
      mediaType,
      fileUrl,
      fileName,
      fileSize,
      fileMime,
      timestamp: Date.now(),
    };

    // Send through WebSocket
    wsRef.current.send(
      JSON.stringify({
        type: 'message',
        message: newMsg,
      })
    );

    // Audio feedback
    if (settings.soundEnabled) sound.playSend();
    if (settings.vibrationEnabled) sound.vibrate(40);
  };

  // Notify typing
  const handleTyping = (isTyping: boolean) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({
          type: 'typing',
          recipientId: activeChatId,
          isTyping,
        })
      );
    }
  };

  // Send Buzz / Nudge
  const handleSendNudge = (targetId: string = activeChatId) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;

    wsRef.current.send(
      JSON.stringify({
        type: 'nudge',
        targetId,
      })
    );

    if (settings.soundEnabled) sound.playNudge();
    if (settings.vibrationEnabled) sound.vibrate([100, 50, 100]);
  };

  // Update profile
  const handleUpdateProfile = (
    name: string,
    avatar: string,
    status: 'online' | 'busy' | 'away'
  ) => {
    const updated = { ...currentUser, name, avatar, status };
    setCurrentUser(updated);

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({
          type: 'update_profile',
          user: updated,
        })
      );
    }
  };

  // Current active conversation messages
  const activeMessages = useMemo(() => {
    if (activeChatId === 'public') {
      return publicMessages;
    }
    return privateMessages[activeChatId] || [];
  }, [activeChatId, publicMessages, privateMessages]);

  const targetPeer = useMemo(() => {
    if (activeChatId === 'public') return null;
    return peers.find((p) => p.id === activeChatId) || null;
  }, [activeChatId, peers]);

  const unreadTotal = useMemo(() => {
    return Object.values(unreadCounts).reduce((a, b) => a + b, 0);
  }, [unreadCounts]);

  // Combined messages for backup export
  const allMessagesForExport = useMemo(() => {
    const privates = Object.values(privateMessages).flat();
    return [...publicMessages, ...privates];
  }, [publicMessages, privateMessages]);

  // Dark themes mapping
  const themeBackgroundClasses = {
    slate: 'bg-slate-950 text-slate-100',
    amoled: 'bg-black text-slate-100',
    navy: 'bg-[#030712] text-slate-100',
    emerald: 'bg-[#02130e] text-slate-100',
    violet: 'bg-[#0b0617] text-slate-100',
  };

  return (
    <div
      dir="rtl"
      className={`min-h-screen flex flex-col font-cairo transition-colors duration-300 ${
        themeBackgroundClasses[settings.preset]
      } ${isShaking ? 'animate-[shake_0.5s_ease-in-out_infinite]' : ''}`}
    >
      {/* Navbar Header */}
      <Navbar
        isConnected={isConnected}
        onlineCount={peers.length}
        onOpenNetworkModal={() => setIsNetworkModalOpen(true)}
        onOpenSettingsModal={() => setIsSettingsModalOpen(true)}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        onToggleMobileDrawer={() => setIsMobileDrawerOpen((prev) => !prev)}
        onSendNudge={() => handleSendNudge(activeChatId)}
        onToggleSearch={() => setIsSearching((prev) => !prev)}
        isSearching={isSearching}
        unreadTotal={unreadTotal}
        accent={settings.accent}
      />

      {/* Main Content Layout */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Desktop Sidebar (Online Peers & Public Room) */}
        <aside className="hidden lg:block w-72 xl:w-80 h-full shrink-0">
          <PeersList
            currentUser={currentUser}
            peers={peers}
            activeChatId={activeChatId}
            onSelectChat={handleSelectChat}
            onSendNudge={handleSendNudge}
            unreadCounts={unreadCounts}
            accent={settings.accent}
          />
        </aside>

        {/* Mobile Peers Drawer Backdrop & Drawer */}
        {isMobileDrawerOpen && (
          <div
            className="lg:hidden fixed inset-0 z-40 bg-black/70 backdrop-blur-sm animate-in fade-in"
            onClick={() => setIsMobileDrawerOpen(false)}
          >
            <div
              className="w-4/5 max-w-sm h-full bg-slate-950 shadow-2xl animate-in slide-in-from-right duration-200"
              onClick={(e) => e.stopPropagation()}
            >
              <PeersList
                currentUser={currentUser}
                peers={peers}
                activeChatId={activeChatId}
                onSelectChat={handleSelectChat}
                onSendNudge={handleSendNudge}
                unreadCounts={unreadCounts}
                accent={settings.accent}
                onCloseMobileDrawer={() => setIsMobileDrawerOpen(false)}
              />
            </div>
          </div>
        )}

        {/* Chat Area */}
        <main className="flex-1 flex flex-col h-full min-w-0">
          <ChatArea
            activeChatId={activeChatId}
            currentUser={currentUser}
            targetPeer={targetPeer}
            onlineCount={peers.length}
            messages={activeMessages}
            typingUsers={typingUsers}
            settings={settings}
            onSendMessage={handleSendMessage}
            onTyping={handleTyping}
            onSendNudge={handleSendNudge}
            onOpenImage={(url, fileName) => setLightboxImage({ url, fileName })}
            onRecordSoundFeedback={() => sound.playRecordStart()}
            isSearching={isSearching}
            onCloseSearch={() => setIsSearching(false)}
          />
        </main>
      </div>

      {/* Network & QR Code Modal */}
      <NetworkModal
        isOpen={isNetworkModalOpen}
        onClose={() => setIsNetworkModalOpen(false)}
        networkInfo={networkInfo}
        onRefreshNetwork={fetchNetworkInfo}
      />

      {/* Settings & Appearance Modal */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        currentUser={currentUser}
        onUpdateProfile={handleUpdateProfile}
        settings={settings}
        onUpdateSettings={setSettings}
        messagesToExport={allMessagesForExport}
        onClearHistory={() => {
          setPublicMessages([]);
          setPrivateMessages({});
        }}
      />

      {/* Media Lightbox */}
      <MediaLightbox
        imageUrl={lightboxImage?.url || null}
        fileName={lightboxImage?.fileName}
        onClose={() => setLightboxImage(null)}
      />

      {/* App Installation Modal */}
      <InstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        deferredPrompt={deferredPrompt}
        onInstallNative={handleInstallNative}
      />
    </div>
  );
}
