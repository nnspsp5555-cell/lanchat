package com.example.lanchat

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class CallActivity : AppCompatActivity() {

    private lateinit var nameV: TextView
    private lateinit var statusV: TextView
    private lateinit var btnAccept: Button
    private lateinit var btnHang: Button
    private lateinit var btnMute: Button
    private lateinit var btnSpk: Button
    private lateinit var btnCam: Button
    private lateinit var btnFlip: Button
    private lateinit var camRow: LinearLayout
    private lateinit var remoteImg: ImageView
    private lateinit var localTex: TextureView
    private lateinit var avatar: TextView
    private val cam = VideoCam()
    private var surf: SurfaceTexture? = null
    private var camRunning = false
    private var started = false

    private val ui = Handler(Looper.getMainLooper())
    private var closing = false
    private val listener: () -> Unit = { refresh() }
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_call)

        nameV = findViewById(R.id.callName)
        statusV = findViewById(R.id.callStatus)
        btnAccept = findViewById(R.id.btnAccept)
        btnHang = findViewById(R.id.btnHang)
        btnMute = findViewById(R.id.btnMute)
        btnSpk = findViewById(R.id.btnSpeaker)
        btnCam = findViewById(R.id.btnCam)
        btnFlip = findViewById(R.id.btnFlip)
        camRow = findViewById(R.id.camRow)
        remoteImg = findViewById(R.id.remoteVideo)
        localTex = findViewById(R.id.localVideo)
        avatar = findViewById(R.id.avatar)
        localTex.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                surf = st
                syncCamera()
            }

            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}

            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                stopCam()
                surf = null
                return true
            }

            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        btnCam.setOnClickListener { CallManager.toggleCam() }
        btnFlip.setOnClickListener {
            cam.front = !cam.front
            stopCam()
            syncCamera()
        }

        btnAccept.setOnClickListener { onAccept() }
        btnHang.setOnClickListener { CallManager.hangup() }
        btnMute.setOnClickListener { CallManager.toggleMute() }
        btnSpk.setOnClickListener { CallManager.toggleSpeaker() }
    }

    override fun onStart() {
        super.onStart()
        started = true
        CallManager.addListener(listener)
        CallManager.frameListener = { bmp -> remoteImg.setImageBitmap(bmp) }
        CallManager.lastFrame?.let { remoteImg.setImageBitmap(it) }
        ui.post(tick)
    }

    override fun onStop() {
        started = false
        CallManager.notifyCamPaused()
        stopCam()
        CallManager.frameListener = null
        CallManager.removeListener(listener)
        ui.removeCallbacks(tick)
        super.onStop()
    }

    private fun stopCam() {
        cam.stop()
        camRunning = false
    }

    /** يشغّل أو يوقف الكاميرا حسب حالة المكالمة */
    private fun syncCamera() {
        val want = started && surf != null && CallManager.video &&
            CallManager.state == CallManager.State.ACTIVE && CallManager.camOn
        if (want && !camRunning) {
            if (cam.start(surf!!)) {
                camRunning = true
                localTex.scaleX = if (cam.front) -1f else 1f
            } else {
                Toast.makeText(this, "تعذّر تشغيل الكاميرا", Toast.LENGTH_LONG).show()
                CallManager.disableCam()
            }
        } else if (!want && camRunning) {
            stopCam()
        }
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun onAccept() {
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (CallManager.video &&
            checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.CAMERA)
        }
        if (need.isEmpty()) {
            CallManager.accept()
        } else {
            requestPermissions(need.toTypedArray(), 7)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                CallManager.accept()
                if (CallManager.video &&
                    checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
                ) {
                    CallManager.disableCam() // نرد بدون كاميرا
                }
            } else {
                Toast.makeText(this, "لازم تسمح للميكروفون حتى تتكلم", Toast.LENGTH_LONG).show()
                CallManager.hangup()
            }
        }
    }

    private fun refresh() {
        nameV.text = CallManager.peerName
        val vid = CallManager.video
        val active = CallManager.state == CallManager.State.ACTIVE
        val showRemote = vid && active && !CallManager.remoteCamOff && CallManager.lastFrame != null
        remoteImg.visibility = if (showRemote) View.VISIBLE else View.GONE
        avatar.visibility = if (showRemote) View.GONE else View.VISIBLE
        localTex.visibility = if (vid && active && CallManager.camOn) View.VISIBLE else View.GONE
        camRow.visibility = if (vid && active) View.VISIBLE else View.GONE
        btnCam.text = if (CallManager.camOn) "📷 إيقاف الكاميرا" else "📷 تشغيل الكاميرا"
        syncCamera()
        when (CallManager.state) {
            CallManager.State.INCOMING -> {
                statusV.text = if (CallManager.video) "مكالمة فيديو واردة…" else "مكالمة واردة…"
                btnAccept.visibility = View.VISIBLE
                btnAccept.text = if (CallManager.video) "🎥 رد" else "📞 رد"
                btnHang.text = "❌ رفض"
                btnMute.visibility = View.GONE
                btnSpk.visibility = View.GONE
            }
            CallManager.State.OUTGOING -> {
                statusV.text = "جاري الاتصال…"
                btnAccept.visibility = View.GONE
                btnHang.text = "📵 إلغاء"
                btnMute.visibility = View.GONE
                btnSpk.visibility = View.GONE
            }
            CallManager.State.ACTIVE -> {
                val s = (SystemClock.elapsedRealtime() - CallManager.startedAt) / 1000
                statusV.text = String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
                btnAccept.visibility = View.GONE
                btnHang.text = "📵 إنهاء"
                btnMute.visibility = View.VISIBLE
                btnSpk.visibility = View.VISIBLE
                btnMute.text = if (CallManager.muted) "🔇 الصوت مقفول" else "🎤 كتم"
                btnSpk.text = if (CallManager.speaker) "🔊 السماعة شغالة" else "📱 سماعة"
            }
            CallManager.State.IDLE -> {
                statusV.text = CallManager.lastReason ?: "انتهت المكالمة"
                btnAccept.visibility = View.GONE
                btnHang.visibility = View.GONE
                btnMute.visibility = View.GONE
                btnSpk.visibility = View.GONE
                if (!closing) {
                    closing = true
                    ui.postDelayed({ finish() }, 1200)
                }
            }
        }
    }
}
