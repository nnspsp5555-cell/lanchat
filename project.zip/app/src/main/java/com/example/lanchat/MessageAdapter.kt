package com.example.lanchat

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MessageAdapter(
    private val items: List<ChatMessage>,
    private val onClick: (ChatMessage) -> Unit
) : RecyclerView.Adapter<MessageAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val bubble: LinearLayout = v.findViewById(R.id.bubble)
        val name: TextView = v.findViewById(R.id.msgName)
        val text: TextView = v.findViewById(R.id.msgText)
        val image: ImageView = v.findViewById(R.id.msgImage)
        val info: TextView = v.findViewById(R.id.msgInfo)
        val time: TextView = v.findViewById(R.id.msgTime)
    }

    private val fmt = SimpleDateFormat("hh:mm a", Locale.getDefault())
    private val cache = LruCache<String, Bitmap>(24)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false))

    override fun getItemCount() = items.size

    private fun thumb(path: String): Bitmap? {
        cache.get(path)?.let { return it }
        return try {
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, b)
            var sample = 1
            while (maxOf(b.outWidth, b.outHeight) / sample > 700) sample *= 2
            val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
            if (bmp != null) cache.put(path, bmp)
            bmp
        } catch (_: Throwable) {
            null
        }
    }

    private fun human(n: Long): String =
        if (n < 1024 * 1024) "${maxOf(1L, n / 1024)} KB"
        else String.format(Locale.US, "%.1f MB", n / 1048576.0)

    override fun onBindViewHolder(h: VH, position: Int) {
        val m = items[position]
        val lp = h.bubble.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (m.mine) Gravity.START else Gravity.END
        h.bubble.layoutParams = lp
        h.bubble.setBackgroundResource(if (m.mine) R.drawable.bubble_me else R.drawable.bubble_other)

        h.name.visibility = if (m.mine) View.GONE else View.VISIBLE
        h.name.text = m.name
        h.text.text = m.text
        h.text.maxWidth = (h.itemView.resources.displayMetrics.widthPixels * 0.72).toInt()
        h.time.text = fmt.format(Date(m.time))
        h.bubble.setOnClickListener { onClick(m) }

        h.text.visibility = View.VISIBLE
        h.image.visibility = View.GONE
        h.info.visibility = View.GONE

        when (m.kind) {
            "image" -> {
                h.text.visibility = View.GONE
                val bmp = if (m.path.isNotEmpty()) thumb(m.path) else null
                if (bmp != null) {
                    h.image.setImageBitmap(bmp)
                    h.image.visibility = View.VISIBLE
                } else {
                    h.info.visibility = View.VISIBLE
                    h.info.text = if (m.failed) "⚠️ فشل تحميل الصورة — اضغط لإعادة المحاولة"
                    else "⏳ جاري تحميل الصورة ${m.progress}%"
                }
            }
            "file" -> {
                h.info.visibility = View.VISIBLE
                h.info.text = when {
                    m.path.isNotEmpty() -> "${human(m.size)} — اضغط للفتح"
                    m.failed -> "⚠️ فشل التحميل — اضغط لإعادة المحاولة"
                    else -> "⏳ جاري التحميل ${m.progress}% (${human(m.size)})"
                }
            }
        }
    }
}
