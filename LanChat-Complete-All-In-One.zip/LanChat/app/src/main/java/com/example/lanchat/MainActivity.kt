package com.example.lanchat

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var chatNet: ChatNet
    private val discoveredDevices = mutableMapOf<String, PeerDevice>()
    private val messagesList = mutableListOf<NetMessage>()
    private lateinit var adapter: MessageAdapter

    private lateinit var txtDeviceCount: TextView
    private lateinit var devicesSpinner: Spinner
    private lateinit var recyclerMessages: RecyclerView
    private lateinit var inputMessage: EditText
    private lateinit var btnSend: ImageButton
    private lateinit var layoutStatus: LinearLayout

    private var myName = "هاتف أندرويد"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        myName = "أندرويد (${(10..99).random()})"

        txtDeviceCount = findViewById(R.id.txtDeviceCount)
        devicesSpinner = findViewById(R.id.devicesSpinner)
        recyclerMessages = findViewById(R.id.recyclerMessages)
        inputMessage = findViewById(R.id.inputMessage)
        btnSend = findViewById(R.id.btnSend)
        layoutStatus = findViewById(R.id.layoutStatus)

        adapter = MessageAdapter(messagesList)
        recyclerMessages.layoutManager = LinearLayoutManager(this).apply {
            stackFromEnd = true
        }
        recyclerMessages.adapter = adapter

        updateDevicesSpinner()

        // Initialize ChatNet - Immediately broadcasts & discovers Wi-Fi devices
        chatNet = ChatNet(
            context = this,
            myName = myName,
            onDeviceFound = { device ->
                discoveredDevices[device.id] = device
                updateDevicesUI()
            },
            onMessageReceived = { msg ->
                adapter.addMessage(msg)
                recyclerMessages.scrollToPosition(messagesList.size - 1)
                vibratePhone()
            }
        )

        chatNet.start()

        btnSend.setOnClickListener {
            val text = inputMessage.text.toString().trim()
            if (text.isNotEmpty()) {
                val selectedIndex = devicesSpinner.selectedItemPosition
                val devices = discoveredDevices.values.toList()

                if (selectedIndex == 0) {
                    // Broadcast to all discovered devices
                    devices.forEach { dev ->
                        chatNet.sendMessage(dev.ip, text) {}
                    }
                    val myMsg = NetMessage("me_${System.currentTimeMillis()}", myName, text, System.currentTimeMillis(), true)
                    adapter.addMessage(myMsg)
                    recyclerMessages.scrollToPosition(messagesList.size - 1)
                } else if (selectedIndex - 1 < devices.size) {
                    val target = devices[selectedIndex - 1]
                    chatNet.sendMessage(target.ip, text) { myMsg ->
                        adapter.addMessage(myMsg)
                        recyclerMessages.scrollToPosition(messagesList.size - 1)
                    }
                }
                inputMessage.setText("")
            }
        }
    }

    private fun updateDevicesUI() {
        val count = discoveredDevices.size
        txtDeviceCount.text = "$count جهاز متصل بالـ Wi-Fi"
        updateDevicesSpinner()
    }

    private fun updateDevicesSpinner() {
        val items = mutableListOf("الجميع (بث عام)")
        discoveredDevices.values.forEach { dev ->
            items.add("${dev.name} (${dev.ip})")
        }
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        devicesSpinner.adapter = spinnerAdapter
    }

    private fun vibratePhone() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            vibrator.vibrate(100)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        chatNet.stop()
    }
}
