plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.lanchat"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.lanchat"
        minSdk = 24
        targetSdk = 34
        versionCode = 11
        versionName = "6.3"
    }

    signingConfigs {
        create("lanchat") {
            storeFile = file("lanchat.keystore")
            storePassword = "lanchat123"
            keyAlias = "lanchat"
            keyPassword = "lanchat123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("lanchat")
        }
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
