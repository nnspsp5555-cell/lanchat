package com.example.lanchat

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.InputFilter
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

/** شاشة محادثة: خاصة مع شخص، أو العامة (conv = "all") */
class ChatActivity : AppCompatActivity() {

    private lateinit var adapter: MessageAdapter
    private lateinit var list: RecyclerView
    private lateinit var titleV: TextView
    private lateinit var sub: TextView
    private lateinit var callBar: TextView
    private lateinit var callBtn: Button
    private lateinit var videoBtn: Button
    private var pendingVideo = false
    private var conv = "all"
    private val shown = ArrayList<ChatMessage>()

    private val callListener: () -> Unit = { updateCallBar() }
    private val msgListener: (ChatMessage) -> Unit = { m ->
        if (m.conv == conv) {
            shown.add(m)
            adapter.notifyItemInserted(shown.size - 1)
            list.scrollToPosition(shown.size - 1)
            ChatNet.unread.remove(conv)
        }
    }
    private val updListener: (ChatMessage) -> Unit = { m ->
        val i = shown.indexOfFirst { it.id == m.id }
        if (i >= 0) adapter.notifyItemChanged(i)
    }
    private val peersListener: (List<String>) -> Unit = { refreshHeader() }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) ChatNet.sendFile(this, uri, true, conv)
    }
    private val pickFile = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) ChatNet.sendFile(this, uri, false, conv)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        ChatNet.init(this)

        list = findViewById(R.id.list)
        titleV = findViewById(R.id.chatTitle)
        sub = findViewById(R.id.chatSub)
        callBar = findViewById(R.id.callBar)
        callBtn = findViewById(R.id.callBtn)
        videoBtn = findViewById(R.id.videoBtn)
        val input = findViewById<EditText>(R.id.input)
        input.filters = arrayOf(InputFilter.LengthFilter(ChatNet.MAX_LEN))

        adapter = MessageAdapter(shown) { onMessageClick(it) }
        list.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        list.adapter = adapter

        findViewById<Button>(R.id.send).setOnClickListener {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) {
                if (conv != "all" && !ChatNet.isOnline(conv)) {
                    Toast.makeText(this, "⚪ غير متصل حالياً، ممكن ما توصل الرسالة", Toast.LENGTH_SHORT).show()
                }
                ChatNet.send(t, conv)
                input.setText("")
            }
        }
        findViewById<Button>(R.id.attach).setOnClickListener {
            AlertDialog.Builder(this)
                .setItems(arrayOf("🖼 صورة", "📁 ملف")) { _, which ->
                    if (which == 0) pickImage.launch("image/*") else pickFile.launch("*/*")
                }
                .show()
        }
        callBtn.setOnClickListener { callContact(false) }
        videoBtn.setOnClickListener { callContact(true) }
        callBar.setOnClickListener { startActivity(Intent(this, CallActivity::class.java)) }

        loadConv()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        loadConv()
    }

    private fun loadConv() {
        conv = intent.getStringExtra("conv") ?: "all"
        ChatNet.openConv = conv
        ChatNet.unread.remove(conv)
        shown.clear()
        shown.addAll(ChatNet.messagesFor(conv))
        adapter.notifyDataSetChanged()
        if (shown.isNotEmpty()) list.scrollToPosition(shown.size - 1)
        refreshHeader()
    }

    override fun onStart() {
        super.onStart()
        ChatNet.activityStarted()
        ChatNet.openConv = conv
        ChatNet.unread.remove(conv)
        ChatNet.addMessageListener(msgListener)
        ChatNet.addUpdateListener(updListener)
        ChatNet.addPeersListener(peersListener)
        CallManager.addListener(callListener)
        try {
            getSystemService(NotificationManager::class.java).cancel(2) // إشعار الرسائل
        } catch (_: Exception) {
        }
        refreshHeader()
        updateCallBar()
    }

    override fun onStop() {
        ChatNet.removeMessageListener(msgListener)
        ChatNet.removeUpdateListener(updListener)
        ChatNet.removePeersListener(peersListener)
        CallManager.removeListener(callListener)
        ChatNet.openConv = null
        ChatNet.activityStopped()
        super.onStop()
    }

    private fun refreshHeader() {
        if (conv == "all") {
            titleV.text = "📢 الدردشة العامة"
            val names = ChatNet.peerList().map { it.name }
            sub.text = if (names.isEmpty()) "لا يوجد أحد متصل" else "🟢 " + names.joinToString("، ")
            callBtn.visibility = View.GONE
            videoBtn.visibility = View.GONE
        } else {
            titleV.text = ChatNet.contacts[conv]?.name ?: "مجهول"
            sub.text = ChatNet.statusText(conv)
            callBtn.visibility = View.VISIBLE
            videoBtn.visibility = View.VISIBLE
        }
    }

    private fun updateCallBar() {
        val n = CallManager.peerName
        val t = when (CallManager.state) {
            CallManager.State.IDLE -> null
            CallManager.State.INCOMING -> "📞 مكالمة واردة من $n — اضغط للرد"
            CallManager.State.OUTGOING -> "📞 جاري الاتصال بـ $n — اضغط للعودة"
            CallManager.State.ACTIVE -> "🟢 مكالمة جارية مع $n — اضغط للعودة"
        }
        callBar.text = t ?: ""
        callBar.visibility = if (t == null) View.GONE else View.VISIBLE
    }

    private fun callContact(video: Boolean) {
        if (CallManager.state != CallManager.State.IDLE) {
            startActivity(Intent(this, CallActivity::class.java))
            return
        }
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (video && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.CAMERA)
        }
        if (need.isNotEmpty()) {
            pendingVideo = video
            requestPermissions(need.toTypedArray(), 2)
            return
        }
        val c = ChatNet.contacts[conv] ?: return
        val peer = ChatNet.peerList().firstOrNull { it.id == c.id } ?: Peer(c.id, c.name, c.ip, 0)
        if (ChatNet.isOnline(c.id)) {
            CallManager.call(this, peer, video)
        } else {
            AlertDialog.Builder(this)
                .setTitle("⚪ ${c.name} غير متصل حالياً")
                .setMessage("تريد تحاول تدق عليه؟")
                .setPositiveButton("حاول") { _, _ -> CallManager.call(this, peer, video) }
                .setNegativeButton("إلغاء", null)
                .show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 2) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                val camOk = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                callContact(pendingVideo && camOk)
            } else {
                Toast.makeText(this, "لازم تسمح للميكروفون حتى تتصل", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun onMessageClick(m: ChatMessage) {
        if (m.kind == "text") return
        if (m.path.isEmpty()) {
            if (m.failed) ChatNet.retry(m)
            return
        }
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", File(m.path))
            val ext = m.fileName.substringAfterLast('.', "").lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                ?: if (m.kind == "image") "image/jpeg" else "*/*"
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (_: Exception) {
            Toast.makeText(this, "ما كو تطبيق يفتح هذا الملف", Toast.LENGTH_LONG).show()
        }
    }
}
