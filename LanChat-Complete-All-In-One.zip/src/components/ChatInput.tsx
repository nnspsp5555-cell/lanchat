import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Paperclip,
  Image,
  Video,
  FileText,
  Mic,
  Square,
  Trash2,
  Smile,
  X,
  Music,
  Loader2,
} from 'lucide-react';
import { AccentColor, ReplyContext } from '../types/chat';
import { fileToBase64, getMediaTypeFromFile, VoiceRecorder } from '../utils/media';

interface ChatInputProps {
  accent: AccentColor;
  replyTo: ReplyContext | null;
  onCancelReply: () => void;
  onSendMessage: (params: {
    content: string;
    mediaType?: 'text' | 'image' | 'video' | 'audio' | 'file';
    fileUrl?: string;
    fileName?: string;
    fileSize?: number;
    fileMime?: string;
  }) => void;
  onTyping: (isTyping: boolean) => void;
  onRecordSoundFeedback: () => void;
}

const QUICK_EMOJIS = ['👍', '❤️', '😂', '🔥', '👏', '⚡', '🚀', '☕', '🎮', '🤝', '🎉', '👋'];

export const ChatInput: React.FC<ChatInputProps> = ({
  accent,
  replyTo,
  onCancelReply,
  onSendMessage,
  onTyping,
  onRecordSoundFeedback,
}) => {
  const [text, setText] = useState('');
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [showEmojiBar, setShowEmojiBar] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgressText, setUploadProgressText] = useState('');

  // Voice recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const recorderRef = useRef<VoiceRecorder | null>(null);
  const timerRef = useRef<any>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const fileTypeFilterRef = useRef<string>('*/*');
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const typingTimerRef = useRef<any>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [text]);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setText(val);

    // Notify typing
    onTyping(true);
    if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
    typingTimerRef.current = setTimeout(() => {
      onTyping(false);
    }, 1500);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSend = () => {
    if (isUploading || isRecording) return;
    const trimmed = text.trim();
    if (!trimmed) return;

    onSendMessage({
      content: trimmed,
      mediaType: 'text',
    });

    setText('');
    onTyping(false);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const addEmoji = (emoji: string) => {
    setText((prev) => prev + emoji);
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  // Open file selector with type filter
  const triggerFileInput = (accept: string) => {
    fileTypeFilterRef.current = accept;
    setShowAttachMenu(false);
    if (fileInputRef.current) {
      fileInputRef.current.accept = accept;
      fileInputRef.current.click();
    }
  };

  const handleFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsUploading(true);
      setUploadProgressText(`جاري تجهيز ${file.name}...`);

      const mediaType = getMediaTypeFromFile(file);
      const dataUrl = await fileToBase64(file);

      // Upload to local server via /api/upload
      setUploadProgressText(`جاري الرفع إلى الخادم المحلي...`);
      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileName: file.name,
          fileType: file.type,
          dataUrl,
        }),
      });

      if (!res.ok) {
        throw new Error('فشل رفع الملف إلى الخادم');
      }

      const data = await res.json();

      onSendMessage({
        content: text.trim(),
        mediaType,
        fileUrl: data.fileUrl,
        fileName: file.name,
        fileSize: file.size,
        fileMime: file.type,
      });

      setText('');
    } catch (err: any) {
      console.error('File upload error:', err);
      alert(err.message || 'حدث خطأ أثناء إرسال الملف');
    } finally {
      setIsUploading(false);
      setUploadProgressText('');
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Voice recording controls
  const startRecording = async () => {
    try {
      const recorder = new VoiceRecorder();
      const started = await recorder.start();
      if (!started) {
        alert('يرجى منح إذن استخدام الميكروفون لتسجيل الصوت');
        return;
      }

      recorderRef.current = recorder;
      setIsRecording(true);
      setRecordingSeconds(0);
      onRecordSoundFeedback();

      timerRef.current = setInterval(() => {
        setRecordingSeconds((s) => s + 1);
      }, 1000);
    } catch (err) {
      console.error('Error starting audio recording:', err);
    }
  };

  const stopAndSendRecording = async () => {
    if (!recorderRef.current) return;
    try {
      clearInterval(timerRef.current);
      setIsUploading(true);
      setUploadProgressText('جاري معالجة التسجيل الصوتي...');

      const { blob, mimeType } = await recorderRef.current.stop();
      setIsRecording(false);

      // Convert audio blob to base64
      const reader = new FileReader();
      reader.onload = async () => {
        const dataUrl = reader.result as string;
        const fileName = `voice_${Date.now()}.webm`;

        const res = await fetch('/api/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileName,
            fileType: mimeType,
            dataUrl,
          }),
        });

        const data = await res.json();

        onSendMessage({
          content: '',
          mediaType: 'audio',
          fileUrl: data.fileUrl,
          fileName: 'مقطع صوتي',
          fileSize: blob.size,
          fileMime: mimeType,
        });

        setIsUploading(false);
        setUploadProgressText('');
      };
      reader.readAsDataURL(blob);
    } catch (err) {
      console.error('Error sending audio note:', err);
      setIsRecording(false);
      setIsUploading(false);
    }
  };

  const cancelRecording = () => {
    clearInterval(timerRef.current);
    if (recorderRef.current) {
      recorderRef.current.cancel();
      recorderRef.current = null;
    }
    setIsRecording(false);
    setRecordingSeconds(0);
  };

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const accentSendBtn: Record<AccentColor, string> = {
    cyan: 'bg-cyan-500 hover:bg-cyan-400 text-slate-950',
    emerald: 'bg-emerald-500 hover:bg-emerald-400 text-slate-950',
    violet: 'bg-violet-500 hover:bg-violet-400 text-white',
    amber: 'bg-amber-500 hover:bg-amber-400 text-slate-950',
    rose: 'bg-rose-500 hover:bg-rose-400 text-white',
    sky: 'bg-sky-500 hover:bg-sky-400 text-slate-950',
  };

  return (
    <div className="relative border-t border-slate-800 bg-slate-950/80 backdrop-blur-lg p-2.5 sm:p-3">
      {/* Hidden file input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelected}
        className="hidden"
      />

      {/* Reply Banner */}
      {replyTo && (
        <div className="mb-2 bg-slate-900 border-r-4 border-cyan-500 rounded-lg p-2 flex items-center justify-between animate-in slide-in-from-bottom-2">
          <div className="min-w-0 text-xs">
            <span className="font-semibold text-cyan-400 block">الرد على {replyTo.senderName}:</span>
            <span className="text-slate-300 truncate block max-w-sm">{replyTo.content || '[مرفق]'}</span>
          </div>
          <button
            onClick={onCancelReply}
            className="p-1 rounded-full text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
          >
            <X size={16} />
          </button>
        </div>
      )}

      {/* Uploading progress notification */}
      {isUploading && (
        <div className="mb-2 bg-slate-900 border border-cyan-500/30 rounded-lg p-2 flex items-center gap-2 text-xs text-cyan-300 animate-pulse">
          <Loader2 size={16} className="animate-spin text-cyan-400" />
          <span>{uploadProgressText}</span>
        </div>
      )}

      {/* Quick Emoji Bar */}
      {showEmojiBar && (
        <div className="mb-2 p-1.5 bg-slate-900/90 border border-slate-800 rounded-xl flex items-center gap-2 overflow-x-auto no-scrollbar">
          {QUICK_EMOJIS.map((emoji) => (
            <button
              key={emoji}
              onClick={() => addEmoji(emoji)}
              className="text-lg p-1 hover:scale-125 transition-transform shrink-0 cursor-pointer"
            >
              {emoji}
            </button>
          ))}
        </div>
      )}

      {/* Attachment Menu Popup */}
      {showAttachMenu && (
        <div
          className="absolute bottom-16 right-4 bg-slate-900 border border-slate-700/80 rounded-2xl p-2 shadow-2xl z-30 flex flex-col gap-1 w-44 animate-in fade-in slide-in-from-bottom-3"
          onClick={(e) => e.stopPropagation()}
        >
          <button
            onClick={() => triggerFileInput('image/*')}
            className="flex items-center gap-2.5 p-2 rounded-xl text-xs text-slate-200 hover:bg-slate-800 hover:text-cyan-400 transition-colors cursor-pointer"
          >
            <div className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-400">
              <Image size={16} />
            </div>
            <span>إرسال صورة</span>
          </button>
          <button
            onClick={() => triggerFileInput('video/*')}
            className="flex items-center gap-2.5 p-2 rounded-xl text-xs text-slate-200 hover:bg-slate-800 hover:text-purple-400 transition-colors cursor-pointer"
          >
            <div className="p-1.5 rounded-lg bg-purple-500/20 text-purple-400">
              <Video size={16} />
            </div>
            <span>إرسال فيديو</span>
          </button>
          <button
            onClick={() => triggerFileInput('audio/*')}
            className="flex items-center gap-2.5 p-2 rounded-xl text-xs text-slate-200 hover:bg-slate-800 hover:text-emerald-400 transition-colors cursor-pointer"
          >
            <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
              <Music size={16} />
            </div>
            <span>ملف صوتي / موسيقى</span>
          </button>
          <button
            onClick={() => triggerFileInput('*/*')}
            className="flex items-center gap-2.5 p-2 rounded-xl text-xs text-slate-200 hover:bg-slate-800 hover:text-amber-400 transition-colors cursor-pointer"
          >
            <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
              <FileText size={16} />
            </div>
            <span>مستند أو ملف / APK</span>
          </button>
        </div>
      )}

      {/* Main Input Row */}
      {isRecording ? (
        // Voice recording interface
        <div className="flex items-center justify-between gap-3 bg-slate-900 border border-rose-500/40 rounded-2xl p-2 px-3 animate-in fade-in">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 rounded-full bg-rose-500 animate-ping" />
            <span className="font-mono text-sm text-rose-400 font-bold">
              {formatTimer(recordingSeconds)}
            </span>
            <div className="flex items-center gap-1">
              <span className="w-1 h-3 bg-rose-400 rounded-full soundwave-bar" />
              <span className="w-1 h-5 bg-rose-400 rounded-full soundwave-bar" style={{ animationDelay: '0.2s' }} />
              <span className="w-1 h-2 bg-rose-400 rounded-full soundwave-bar" style={{ animationDelay: '0.4s' }} />
              <span className="w-1 h-6 bg-rose-400 rounded-full soundwave-bar" style={{ animationDelay: '0.1s' }} />
            </div>
            <span className="text-xs text-slate-400 hidden sm:inline">جاري التسجيل...</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={cancelRecording}
              className="p-2 rounded-xl bg-slate-800 hover:bg-rose-900/40 text-rose-400 transition-colors cursor-pointer"
              title="إلغاء التسجيل"
            >
              <Trash2 size={18} />
            </button>
            <button
              onClick={stopAndSendRecording}
              className="p-2 px-3 rounded-xl bg-rose-500 hover:bg-rose-400 text-white flex items-center gap-1.5 text-xs font-bold transition-all shadow-lg cursor-pointer"
              title="إرسال الصوت"
            >
              <Send size={15} className="fill-current rotate-180" />
              <span>إرسال</span>
            </button>
          </div>
        </div>
      ) : (
        // Normal text and attachment row
        <div className="flex items-end gap-2">
          {/* Attach Button */}
          <button
            onClick={() => setShowAttachMenu((prev) => !prev)}
            className={`p-2.5 rounded-2xl transition-all cursor-pointer ${
              showAttachMenu
                ? 'bg-slate-800 text-cyan-400 rotate-45'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
            title="إرفاق ملف أو وسائط"
          >
            <Paperclip size={20} />
          </button>

          {/* Emoji Toggle */}
          <button
            onClick={() => setShowEmojiBar((prev) => !prev)}
            className={`p-2.5 rounded-2xl transition-all cursor-pointer ${
              showEmojiBar
                ? 'bg-slate-800 text-amber-400'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
            title="رموز تعبيرية"
          >
            <Smile size={20} />
          </button>

          {/* Text Area */}
          <div className="flex-1 bg-slate-900/90 border border-slate-800 focus-within:border-slate-700 rounded-2xl px-3 py-1.5 transition-all">
            <textarea
              ref={textareaRef}
              rows={1}
              value={text}
              onChange={handleTextChange}
              onKeyDown={handleKeyDown}
              placeholder="اكتب رسالة هنا..."
              className="w-full bg-transparent text-slate-100 placeholder-slate-500 text-sm outline-none resize-none max-h-32 leading-relaxed"
            />
          </div>

          {/* Voice recording or Send button */}
          {text.trim() ? (
            <button
              onClick={handleSend}
              className={`p-2.5 rounded-2xl shadow-md transition-all active:scale-95 cursor-pointer shrink-0 ${accentSendBtn[accent]}`}
              title="إرسال (Enter)"
            >
              <Send size={19} className="rotate-180 fill-current" />
            </button>
          ) : (
            <button
              onClick={startRecording}
              className="p-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-400 hover:border-cyan-500/40 transition-all active:scale-95 cursor-pointer shrink-0"
              title="تسجيل رسالة صوتية"
            >
              <Mic size={20} />
            </button>
          )}
        </div>
      )}
    </div>
  );
};
