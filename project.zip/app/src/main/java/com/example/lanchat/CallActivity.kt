package com.example.lanchat

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class CallActivity : AppCompatActivity() {

    private lateinit var nameV: TextView
    private lateinit var statusV: TextView
    private lateinit var btnAccept: Button
    private lateinit var btnHang: Button
    private lateinit var btnMute: Button
    private lateinit var btnSpk: Button

    private val ui = Handler(Looper.getMainLooper())
    private var closing = false
    private val listener: () -> Unit = { refresh() }
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_call)

        nameV = findViewById(R.id.callName)
        statusV = findViewById(R.id.callStatus)
        btnAccept = findViewById(R.id.btnAccept)
        btnHang = findViewById(R.id.btnHang)
        btnMute = findViewById(R.id.btnMute)
        btnSpk = findViewById(R.id.btnSpeaker)

        btnAccept.setOnClickListener { onAccept() }
        btnHang.setOnClickListener { CallManager.hangup() }
        btnMute.setOnClickListener { CallManager.toggleMute() }
        btnSpk.setOnClickListener { CallManager.toggleSpeaker() }
    }

    override fun onStart() {
        super.onStart()
        CallManager.addListener(listener)
        ui.post(tick)
    }

    override fun onStop() {
        CallManager.removeListener(listener)
        ui.removeCallbacks(tick)
        super.onStop()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun onAccept() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            CallManager.accept()
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                CallManager.accept()
            } else {
                Toast.makeText(this, "لازم تسمح للميكروفون حتى تتكلم", Toast.LENGTH_LONG).show()
                CallManager.hangup()
            }
        }
    }

    private fun refresh() {
        nameV.text = CallManager.peerName
        when (CallManager.state) {
            CallManager.State.INCOMING -> {
                statusV.text = "مكالمة واردة…"
                btnAccept.visibility = View.VISIBLE
                btnHang.text = "❌ رفض"
                btnMute.visibility = View.GONE
                btnSpk.visibility = View.GONE
            }
            CallManager.State.OUTGOING -> {
                statusV.text = "جاري الاتصال…"
                btnAccept.visibility = View.GONE
                btnHang.text = "📵 إلغاء"
                btnMute.visibility = View.GONE
                btnSpk.visibility = View.GONE
            }
            CallManager.State.ACTIVE -> {
                val s = (SystemClock.elapsedRealtime() - CallManager.startedAt) / 1000
                statusV.text = String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
                btnAccept.visibility = View.GONE
                btnHang.text = "📵 إنهاء"
                btnMute.visibility = View.VISIBLE
                btnSpk.visibility = View.VISIBLE
                btnMute.text = if (CallManager.muted) "🔇 الصوت مقفول" else "🎤 كتم"
                btnSpk.text = if (CallManager.speaker) "🔊 السماعة شغالة" else "📱 سماعة"
            }
            CallManager.State.IDLE -> {
                statusV.text = CallManager.lastReason ?: "انتهت المكالمة"
                btnAccept.visibility = View.GONE
                btnHang.visibility = View.GONE
                btnMute.visibility = View.GONE
                btnSpk.visibility = View.GONE
                if (!closing) {
                    closing = true
                    ui.postDelayed({ finish() }, 1200)
                }
            }
        }
    }
}
