package com.example.lanchat

import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * شاشة رمز الدخول. تظهر مرة وحدة بس على كل تلفون، أول ما يثبت التطبيق.
 * الرمز الصحيح محدد بـ res/values/strings.xml (access_code).
 */
class GateActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("lanchat", MODE_PRIVATE)
        if (prefs.getBoolean("gate_ok", false)) {
            goMain()
            return
        }

        setContentView(R.layout.activity_gate)
        val code = findViewById<EditText>(R.id.code)
        val err = findViewById<TextView>(R.id.err)
        code.filters = arrayOf(InputFilter.LengthFilter(32))

        findViewById<Button>(R.id.go).setOnClickListener {
            val expected = getString(R.string.access_code).trim()
            val typed = code.text.toString().trim()
            if (expected.isNotEmpty() && typed == expected) {
                prefs.edit().putBoolean("gate_ok", true).apply()
                goMain()
            } else {
                err.visibility = android.view.View.VISIBLE
                code.text.clear()
            }
        }
    }

    private fun goMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
