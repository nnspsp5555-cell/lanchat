package com.example.lanchat

import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MessageAdapter(private val items: List<ChatMessage>) :
    RecyclerView.Adapter<MessageAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val bubble: LinearLayout = v.findViewById(R.id.bubble)
        val name: TextView = v.findViewById(R.id.msgName)
        val text: TextView = v.findViewById(R.id.msgText)
        val time: TextView = v.findViewById(R.id.msgTime)
    }

    private val fmt = SimpleDateFormat("hh:mm a", Locale.getDefault())

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val m = items[position]
        val lp = h.bubble.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (m.mine) Gravity.START else Gravity.END
        h.bubble.layoutParams = lp
        h.bubble.setBackgroundResource(if (m.mine) R.drawable.bubble_me else R.drawable.bubble_other)

        h.name.visibility = if (m.mine) View.GONE else View.VISIBLE
        h.name.text = m.name
        h.text.text = m.text
        h.text.maxWidth = (h.itemView.resources.displayMetrics.widthPixels * 0.72).toInt()
        h.time.text = fmt.format(Date(m.time))
    }
}
