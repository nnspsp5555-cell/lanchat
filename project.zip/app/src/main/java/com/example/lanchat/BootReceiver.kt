package com.example.lanchat

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** يشغّل الدردشة تلقائياً بعد إعادة تشغيل التلفون أو تحديث التطبيق، بدون ما تفتح التطبيق */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val name = context.getSharedPreferences("lanchat", Context.MODE_PRIVATE)
            .getString("name", "") ?: ""
        if (name.isBlank()) return
        try {
            ContextCompat.startForegroundService(context, Intent(context, ChatService::class.java))
        } catch (_: Exception) {
        }
    }
}
