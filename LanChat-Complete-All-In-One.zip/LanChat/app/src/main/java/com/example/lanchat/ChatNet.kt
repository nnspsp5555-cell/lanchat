package com.example.lanchat

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.*

data class PeerDevice(
    val id: String,
    val name: String,
    val ip: String,
    var lastSeen: Long = System.currentTimeMillis()
)

data class NetMessage(
    val id: String,
    val senderName: String,
    val content: String,
    val timestamp: Long,
    val isMe: Boolean = false
)

class ChatNet(
    private val context: Context,
    private val myName: String,
    private val onDeviceFound: (PeerDevice) -> Unit,
    private val onMessageReceived: (NetMessage) -> Unit
) {
    companion object {
        const val UDP_PORT = 8888
        const val TCP_PORT = 8889
    }

    private var multicastLock: WifiManager.MulticastLock? = null
    private var udpSocket: DatagramSocket? = null
    private var tcpServer: ServerSocket? = null
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var isRunning = false
    val myId = "android_" + (1000..9999).random()

    fun start() {
        if (isRunning) return
        isRunning = true

        // Acquire MulticastLock on Android to allow UDP Broadcast
        try {
            val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            multicastLock = wifi.createMulticastLock("LanChatLock").apply {
                setReferenceCounted(true)
                acquire()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        startUdpListener()
        startTcpServer()
        startBroadcasting()
    }

    // Immediately broadcasts presence to all devices on Wi-Fi
    private fun startBroadcasting() {
        scope.launch {
            while (isRunning) {
                try {
                    val myIp = getLocalIpAddress()
                    if (myIp != null) {
                        val json = JSONObject().apply {
                            put("type", "HEARTBEAT")
                            put("id", myId)
                            put("name", myName)
                            put("ip", myIp)
                            put("timestamp", System.currentTimeMillis())
                        }.toString()

                        val bytes = json.toByteArray()
                        val broadcastAddress = InetAddress.getByName("255.255.255.255")
                        val packet = DatagramPacket(bytes, bytes.size, broadcastAddress, UDP_PORT)

                        udpSocket?.send(packet)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                delay(2500) // Broadcast every 2.5 seconds
            }
        }
    }

    // Listens for UDP broadcasts from other phones on the Wi-Fi
    private fun startUdpListener() {
        scope.launch {
            try {
                udpSocket = DatagramSocket(UDP_PORT).apply {
                    broadcast = true
                    reuseAddress = true
                }
                val buffer = ByteArray(2048)

                while (isRunning) {
                    val packet = DatagramPacket(buffer, buffer.size)
                    udpSocket?.receive(packet)

                    val message = String(packet.data, 0, packet.length)
                    val json = JSONObject(message)

                    val senderId = json.optString("id")
                    val senderName = json.optString("name")
                    val senderIp = packet.address.hostAddress ?: json.optString("ip")

                    // Ignore self broadcasts
                    if (senderId != myId && senderIp.isNotEmpty()) {
                        val device = PeerDevice(
                            id = senderId,
                            name = senderName,
                            ip = senderIp,
                            lastSeen = System.currentTimeMillis()
                        )
                        withContext(Dispatchers.Main) {
                            onDeviceFound(device)
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Listens for incoming chat messages over TCP
    private fun startTcpServer() {
        scope.launch {
            try {
                tcpServer = ServerSocket(TCP_PORT)
                while (isRunning) {
                    val client = tcpServer?.accept() ?: continue
                    scope.launch {
                        try {
                            val reader = BufferedReader(InputStreamReader(client.getInputStream()))
                            val line = reader.readLine()
                            if (line != null) {
                                val json = JSONObject(line)
                                val msg = NetMessage(
                                    id = json.optString("id", "${System.currentTimeMillis()}"),
                                    senderName = json.optString("senderName", "مجهول"),
                                    content = json.optString("content", ""),
                                    timestamp = json.optLong("timestamp", System.currentTimeMillis()),
                                    isMe = false
                                )
                                withContext(Dispatchers.Main) {
                                    onMessageReceived(msg)
                                }
                            }
                            client.close()
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Sends a direct message to a peer IP address
    fun sendMessage(targetIp: String, content: String, onSent: (NetMessage) -> Unit) {
        scope.launch {
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(targetIp, TCP_PORT), 3000)

                val out = PrintWriter(socket.getOutputStream(), true)
                val msgId = "msg_${System.currentTimeMillis()}"
                val json = JSONObject().apply {
                    put("id", msgId)
                    put("senderName", myName)
                    put("content", content)
                    put("timestamp", System.currentTimeMillis())
                }.toString()

                out.println(json)
                socket.close()

                val localMsg = NetMessage(
                    id = msgId,
                    senderName = myName,
                    content = content,
                    timestamp = System.currentTimeMillis(),
                    isMe = true
                )
                withContext(Dispatchers.Main) {
                    onSent(localMsg)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun getLocalIpAddress(): String? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    fun stop() {
        isRunning = false
        try {
            udpSocket?.close()
            tcpServer?.close()
            multicastLock?.release()
            scope.cancel()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
