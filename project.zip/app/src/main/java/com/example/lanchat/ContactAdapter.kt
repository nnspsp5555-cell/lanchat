package com.example.lanchat

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class ContactItem(
    val id: String,
    val title: String,
    val status: String,
    val unread: Int
)

class ContactAdapter(
    private val items: List<ContactItem>,
    private val onClick: (ContactItem) -> Unit,
    private val onLong: (ContactItem) -> Unit
) : RecyclerView.Adapter<ContactAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.cName)
        val status: TextView = v.findViewById(R.id.cStatus)
        val badge: TextView = v.findViewById(R.id.cBadge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_contact, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val it0 = items[position]
        h.name.text = it0.title
        h.status.text = it0.status
        if (it0.unread > 0) {
            h.badge.visibility = View.VISIBLE
            h.badge.text = if (it0.unread > 99) "99+" else it0.unread.toString()
        } else {
            h.badge.visibility = View.GONE
        }
        h.itemView.setOnClickListener { onClick(it0) }
        h.itemView.setOnLongClickListener {
            onLong(it0)
            true
        }
    }
}
