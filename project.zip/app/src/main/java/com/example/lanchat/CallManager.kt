package com.example.lanchat

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.Ringtone
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * المكالمات الصوتية: التحكم (اتصال/رد/إنهاء) يمشي عبر نفس قناة الدردشة UDP،
 * والصوت يمشي مباشرة بين الجهازين على منفذ ثاني (UDP) بدون سيرفر.
 * كل الدوال العامة تُستدعى من الخيط الرئيسي.
 */
object CallManager {
    enum class State { IDLE, OUTGOING, INCOMING, ACTIVE }

    private const val AUDIO_PORT = 45455

    @Volatile
    private var rate = 16000

    @Volatile
    private var frame = 640 // 20 ملي ثانية من الصوت (بايت)
    private const val CH_CALL = "lanchat_calls"
    private const val ID_CALL = 3
    private const val RING_TIMEOUT = 35_000L
    private const val SILENCE_TIMEOUT = 10_000L

    private val main = Handler(Looper.getMainLooper())
    private lateinit var app: Context

    @Volatile
    var state = State.IDLE
        private set
    var peerName = ""
        private set
    var lastReason: String? = null
        private set
    var startedAt = 0L
        private set

    @Volatile
    var muted = false
        private set
    var speaker = false
        private set

    private var viaBt = false
    private var bt: BtLink? = null
    private var peerId = ""
    private var peerIp = ""
    private var callId = ""
    private val ended = LinkedHashSet<String>()

    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    fun addListener(l: () -> Unit) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    private fun changed() {
        for (l in listeners) l()
    }

    fun init(ctx: Context) {
        app = ctx.applicationContext
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CH_CALL, "المكالمات", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null)
            ch.enableVibration(false)
            app.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    // ───────────── واجهة الاستخدام ─────────────

    fun call(ctx: Context, peer: Peer) {
        if (state != State.IDLE) return
        init(ctx)
        callId = ChatNet.deviceId + "-" + System.currentTimeMillis()
        peerId = peer.id
        peerName = peer.name
        peerIp = peer.ip
        speaker = false
        muted = false
        lastReason = null
        state = State.OUTGOING
        sendSignal("call")
        startTone()
        main.removeCallbacks(ringTimeout)
        main.postDelayed(ringTimeout, RING_TIMEOUT)
        changed()
        launchUi()
    }

    fun accept() {
        if (state != State.INCOMING) return
        sendSignal("acc")
        goActive()
    }

    /** إنهاء المكالمة أو رفضها */
    fun hangup() {
        finish(true, null)
    }

    fun toggleMute() {
        muted = !muted
        changed()
    }

    fun toggleSpeaker() {
        speaker = !speaker
        try {
            am?.isSpeakerphoneOn = speaker
        } catch (_: Exception) {
        }
        changed()
    }

    // ───────────── إشارات التحكم ─────────────

    private fun json(t: String, c: String): String =
        JSONObject().put("t", t).put("c", c).put("d", ChatNet.deviceId).put("n", ChatNet.myName).toString()

    private fun sendSignal(t: String) {
        if (viaBt) bt?.sendSignal(json(t, callId))
        else ChatNet.sendTo(peerIp, json(t, callId), 3)
    }

    // ───────────── مكالمة بلوتوث ─────────────

    @SuppressLint("MissingPermission")
    fun callBt(ctx: Context, dev: BluetoothDevice) {
        if (state != State.IDLE) return
        init(ctx)
        callId = ChatNet.deviceId + "-" + System.currentTimeMillis()
        peerId = dev.address
        peerName = try {
            dev.name ?: dev.address
        } catch (_: Exception) {
            dev.address
        }
        peerIp = ""
        viaBt = true
        bt = null
        speaker = false
        muted = false
        lastReason = null
        state = State.OUTGOING
        startTone()
        main.removeCallbacks(ringTimeout)
        main.postDelayed(ringTimeout, RING_TIMEOUT)
        changed()
        launchUi()
        val myCall = callId
        thread(name = "bt-connect", isDaemon = true) {
            var link: BtLink? = null
            try {
                val sock = dev.createInsecureRfcommSocketToServiceRecord(BtServer.APP_UUID)
                sock.connect()
                link = BtLink(sock)
            } catch (_: Exception) {
            }
            val l = link
            main.post {
                if (state != State.OUTGOING || callId != myCall) {
                    l?.closeNow()
                } else if (l == null) {
                    finish(false, "تعذّر الاتصال: تأكد التطبيق شغال عند الثاني والبلوتوث مفعّل وأنتم مقرونين")
                } else {
                    l.claimed = true
                    bt = l
                    sendSignal("call")
                    thread(name = "bt-read", isDaemon = true) {
                        l.readLoop(
                            { j -> main.post { onBtSignal(l, j) } },
                            { b -> onBtAudio(b) },
                            { main.post { onBtClosed(l) } }
                        )
                    }
                }
            }
        }
    }

    fun onBtSignal(link: BtLink, raw: String) {
        val o = try {
            JSONObject(raw)
        } catch (_: Exception) {
            return
        }
        val c = o.optString("c")
        val t = o.optString("t")
        if (c.isEmpty() || t.isEmpty()) return
        onSignal(t, c, o.optString("d"), o.optString("n").take(24), "", link)
    }

    fun onBtAudio(b: ByteArray) {
        if (audioOn && b.size == frame) {
            lastRx = SystemClock.elapsedRealtime()
            queue.offer(b)
        }
    }

    fun onBtClosed(link: BtLink) {
        if (bt === link && state != State.IDLE) finish(false, "انقطع الاتصال")
    }

    /** تصل من خيط الشبكة عبر main.post */
    fun onSignal(t: String, c: String, d: String, n: String, ip: String, link: BtLink? = null) {
        if (link != null && state == State.IDLE && t != "call") {
            link.closeNow()
            return
        }
        when (t) {
            "call" -> {
                if (c in ended) {
                    link?.closeNow()
                    return
                }
                if (state == State.IDLE) {
                    if (!::app.isInitialized) {
                        link?.closeNow()
                        return
                    }
                    callId = c
                    peerId = d
                    peerName = n
                    peerIp = ip
                    viaBt = link != null
                    bt = link
                    link?.claimed = true
                    speaker = false
                    muted = false
                    lastReason = null
                    state = State.INCOMING
                    startRinging()
                    showIncomingNotification()
                    main.removeCallbacks(ringTimeout)
                    main.postDelayed(ringTimeout, RING_TIMEOUT)
                    changed()
                    launchUi()
                } else if (c != callId) {
                    if (link != null) {
                        link.sendSignal(json("busy", c))
                        link.closeLater()
                    } else {
                        ChatNet.sendTo(ip, json("busy", c), 2)
                    }
                }
            }
            "acc" -> {
                if (c == callId && state == State.OUTGOING && (viaBt || d == peerId)) {
                    if (viaBt) {
                        if (n.isNotEmpty()) peerName = n
                    } else {
                        peerIp = ip
                    }
                    goActive()
                }
            }
            "end", "busy" -> {
                if (c == callId && state != State.IDLE) {
                    val r = when {
                        t == "busy" -> "المستخدم مشغول بمكالمة ثانية"
                        state == State.OUTGOING -> "تم رفض المكالمة"
                        else -> "انتهت المكالمة"
                    }
                    finish(false, r)
                }
            }
        }
    }

    private val ringTimeout = Runnable {
        if (state == State.OUTGOING) finish(true, "ما رد على المكالمة")
        else if (state == State.INCOMING) finish(false, null)
    }

    private val watchdog = object : Runnable {
        override fun run() {
            if (state != State.ACTIVE) return
            if (SystemClock.elapsedRealtime() - lastRx > SILENCE_TIMEOUT) {
                finish(true, "انقطع الاتصال")
                return
            }
            main.postDelayed(this, 2000)
        }
    }

    private fun goActive() {
        main.removeCallbacks(ringTimeout)
        stopRinging()
        stopTone()
        cancelNotification()
        muted = false
        startedAt = SystemClock.elapsedRealtime()
        lastRx = startedAt
        state = State.ACTIVE
        changed() // الخدمة تسمع هذا التغيير وترفع نوعها للميكروفون
        if (!startAudio()) {
            finish(true, "تعذّر تشغيل الميكروفون")
            return
        }
        main.removeCallbacks(watchdog)
        main.postDelayed(watchdog, 2000)
    }

    private fun finish(notifyPeer: Boolean, reason: String?) {
        if (state == State.IDLE) return
        if (notifyPeer) sendSignal("end")
        ended.add(callId)
        if (ended.size > 20) ended.remove(ended.first())
        main.removeCallbacks(ringTimeout)
        main.removeCallbacks(watchdog)
        stopRinging()
        stopTone()
        cancelNotification()
        state = State.IDLE
        lastReason = reason
        stopAudio()
        bt?.closeLater()
        bt = null
        viaBt = false
        changed()
    }

    // ───────────── الصوت ─────────────

    private var am: AudioManager? = null
    private var prevMode = AudioManager.MODE_NORMAL
    private var wifiLock: WifiManager.WifiLock? = null
    private var asock: DatagramSocket? = null
    private val queue = LinkedBlockingQueue<ByteArray>()

    @Volatile
    private var audioOn = false

    @Volatile
    private var lastRx = 0L

    private fun startAudio(): Boolean {
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) return false
        val link = bt
        if (viaBt && link == null) return false
        rate = if (viaBt) 8000 else 16000
        frame = rate / 50 * 2
        val rt = rate
        val fr = frame
        val pre = if (viaBt) 5 else 3
        val ip: InetAddress? = if (viaBt) null else try {
            InetAddress.getByName(peerIp)
        } catch (_: Exception) {
            return false
        }
        try {
            val a = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am = a
            prevMode = a.mode
            a.mode = AudioManager.MODE_IN_COMMUNICATION
            a.isSpeakerphoneOn = speaker

            try {
                val w = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                else WifiManager.WIFI_MODE_FULL_HIGH_PERF
                wifiLock = w.createWifiLock(mode, "lanchat-call").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            } catch (_: Exception) {
            }

            val sock: DatagramSocket? = if (viaBt) null else DatagramSocket(null).apply {
                reuseAddress = true
                bind(InetSocketAddress(AUDIO_PORT))
            }
            asock = sock

            val minRec = AudioRecord.getMinBufferSize(
                rt, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rec = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION, rt,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minRec, fr * 6)
            )
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                rec.release()
                return false
            }
            var aec: AcousticEchoCanceler? = null
            var ns: NoiseSuppressor? = null
            try {
                if (AcousticEchoCanceler.isAvailable()) {
                    aec = AcousticEchoCanceler.create(rec.audioSessionId)
                    aec?.enabled = true
                }
            } catch (_: Exception) {
            }
            try {
                if (NoiseSuppressor.isAvailable()) {
                    ns = NoiseSuppressor.create(rec.audioSessionId)
                    ns?.enabled = true
                }
            } catch (_: Exception) {
            }

            val minTrk = AudioTrack.getMinBufferSize(
                rt, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val trk = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rt)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minTrk, fr * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            queue.clear()
            audioOn = true

            // إرسال: الميكروفون ← الشبكة
            thread(name = "call-tx", isDaemon = true) {
                val buf = ByteArray(fr)
                val pkt = ByteArray(fr + 2)
                var seq = 0
                try {
                    rec.startRecording()
                    while (audioOn) {
                        var got = 0
                        while (got < fr && audioOn) {
                            val n = rec.read(buf, got, fr - got)
                            if (n > 0) got += n else nap(5)
                        }
                        if (got < fr) break
                        if (muted) java.util.Arrays.fill(buf, 0.toByte()) // صمت، لكن نبقي الحزم تمشي
                        pkt[0] = (seq shr 8).toByte()
                        pkt[1] = seq.toByte()
                        seq = (seq + 1) and 0xFFFF
                        System.arraycopy(buf, 0, pkt, 2, fr)
                        if (link != null) {
                            if (!link.write(2, buf, fr)) break
                        } else {
                            try {
                                sock!!.send(DatagramPacket(pkt, pkt.size, ip!!, AUDIO_PORT))
                            } catch (_: Exception) {
                            }
                        }
                    }
                } catch (_: Exception) {
                } finally {
                    try {
                        rec.stop()
                    } catch (_: Exception) {
                    }
                    try {
                        rec.release()
                    } catch (_: Exception) {
                    }
                    try {
                        aec?.release()
                    } catch (_: Exception) {
                    }
                    try {
                        ns?.release()
                    } catch (_: Exception) {
                    }
                }
            }

            // استقبال: الشبكة ← الطابور
            if (sock != null) thread(name = "call-rx", isDaemon = true) {
                val buf = ByteArray(fr + 64)
                while (audioOn) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        sock.receive(p)
                        if (p.length == fr + 2) {
                            lastRx = SystemClock.elapsedRealtime()
                            queue.offer(buf.copyOfRange(2, p.length))
                        }
                    } catch (_: Exception) {
                        if (audioOn) nap(10) else break
                    }
                }
            }

            // تشغيل: الطابور ← السماعة
            thread(name = "call-play", isDaemon = true) {
                var started = false
                try {
                    trk.play()
                    while (audioOn) {
                        if (!started) {
                            if (queue.size >= pre) started = true else {
                                nap(10)
                                continue
                            }
                        }
                        if (queue.size > 10) {
                            while (queue.size > 4) queue.poll()
                        }
                        val f = queue.poll(60, TimeUnit.MILLISECONDS)
                        if (f == null) {
                            started = false
                            continue
                        }
                        trk.write(f, 0, f.size)
                    }
                } catch (_: Exception) {
                } finally {
                    try {
                        trk.stop()
                    } catch (_: Exception) {
                    }
                    try {
                        trk.release()
                    } catch (_: Exception) {
                    }
                }
            }
            return true
        } catch (_: Exception) {
            return false
        }
    }

    private fun stopAudio() {
        audioOn = false
        try {
            asock?.close()
        } catch (_: Exception) {
        }
        asock = null
        queue.clear()
        try {
            am?.isSpeakerphoneOn = false
            am?.mode = prevMode
        } catch (_: Exception) {
        }
        am = null
        try {
            wifiLock?.release()
        } catch (_: Exception) {
        }
        wifiLock = null
    }

    // ───────────── رنين وإشعار ─────────────

    private var ringtone: Ringtone? = null
    private var tone: ToneGenerator? = null

    private fun startRinging() {
        try {
            val r = RingtoneManager.getRingtone(
                app, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            )
            if (r != null) {
                if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
                r.play()
                ringtone = r
            }
        } catch (_: Exception) {
        }
        try {
            val v = app.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            val pat = longArrayOf(0, 800, 800)
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pat, 0))
            else v.vibrate(pat, 0)
        } catch (_: Exception) {
        }
    }

    private fun stopRinging() {
        try {
            ringtone?.stop()
        } catch (_: Exception) {
        }
        ringtone = null
        try {
            (app.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel()
        } catch (_: Exception) {
        }
    }

    private fun startTone() {
        try {
            val t = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 70)
            t.startTone(ToneGenerator.TONE_SUP_RINGTONE)
            tone = t
        } catch (_: Exception) {
        }
    }

    private fun stopTone() {
        try {
            tone?.stopTone()
            tone?.release()
        } catch (_: Exception) {
        }
        tone = null
    }

    private fun showIncomingNotification() {
        try {
            val open = PendingIntent.getActivity(
                app, 10,
                Intent(app, CallActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val rej = PendingIntent.getService(
                app, 11,
                Intent(app, ChatService::class.java).setAction(ChatService.ACTION_REJECT),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = NotificationCompat.Builder(app, CH_CALL)
                .setSmallIcon(android.R.drawable.sym_action_call)
                .setContentTitle("📞 مكالمة واردة")
                .setContentText(peerName)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setOngoing(true)
                .setFullScreenIntent(open, true)
                .setContentIntent(open)
                .addAction(0, "رفض", rej)
                .build()
            app.getSystemService(NotificationManager::class.java).notify(ID_CALL, n)
        } catch (_: Exception) {
        }
    }

    private fun cancelNotification() {
        try {
            app.getSystemService(NotificationManager::class.java).cancel(ID_CALL)
        } catch (_: Exception) {
        }
    }

    private fun launchUi() {
        try {
            app.startActivity(
                Intent(app, CallActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        } catch (_: Exception) {
        }
    }

    private fun nap(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }
}
