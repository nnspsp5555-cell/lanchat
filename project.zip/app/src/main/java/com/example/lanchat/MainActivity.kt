package com.example.lanchat

import android.Manifest
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Shader
import android.bluetooth.BluetoothAdapter
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputFilter
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.io.FileOutputStream

/** الشاشة الرئيسية: قائمة الأشخاص المحفوظين (محادثات خاصة) + العامة */
class MainActivity : AppCompatActivity() {

    private lateinit var online: TextView
    private lateinit var status: TextView
    private lateinit var callBar: TextView
    private lateinit var adapter: ContactAdapter
    private val items = ArrayList<ContactItem>()
    private var afterMic: (() -> Unit)? = null
    private lateinit var avatarImg: ImageView
    private lateinit var crownText: TextView
    private lateinit var dotView: View

    private val pickAvatar = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveAvatar(uri)
    }

    private val callListener: () -> Unit = { updateCallBar() }
    private val msgListener: (ChatMessage) -> Unit = { rebuild() }
    private val peersListener: (List<String>) -> Unit = { names ->
        if (names.isEmpty()) {
            online.text = "غير متصل حالياً"
            dotView.backgroundTintList = android.content.res.ColorStateList.valueOf(
                android.graphics.Color.parseColor("#64748B")
            )
        } else {
            online.text = "متصل محلياً (${names.size} جهاز)"
            dotView.backgroundTintList = android.content.res.ColorStateList.valueOf(
                android.graphics.Color.parseColor("#22C55E")
            )
        }
        rebuild()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        ChatNet.init(this)

        online = findViewById(R.id.online)
        status = findViewById(R.id.status)
        callBar = findViewById(R.id.callBar)
        val list = findViewById<RecyclerView>(R.id.list)
        avatarImg = findViewById(R.id.avatarImg)
        crownText = findViewById(R.id.crownText)
        dotView = findViewById(R.id.dot)
        findViewById<FrameLayout>(R.id.avatarBadge).setOnClickListener { pickAvatar.launch("image/*") }
        loadAvatar()

        adapter = ContactAdapter(items, { openChat(it.id) }, { confirmDelete(it) })
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        callBar.setOnClickListener { startActivity(Intent(this, CallActivity::class.java)) }
        findViewById<Button>(R.id.refreshBtn).setOnClickListener {
            ContextCompat.startForegroundService(this, Intent(this, ChatService::class.java))
            ChatNet.refresh()
            online.text = "🔄 جاري البحث عن الأجهزة…"
            Toast.makeText(this, "تم التحديث", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btBtn).setOnClickListener {
            if (CallManager.state != CallManager.State.IDLE) {
                startActivity(Intent(this, CallActivity::class.java))
            } else {
                ensureMic { btCallDialog() }
            }
        }

        ensureName()
        rebuild()
    }

    override fun onStart() {
        super.onStart()
        ChatNet.activityStarted()
        ChatNet.addMessageListener(msgListener)
        ChatNet.addPeersListener(peersListener)
        CallManager.addListener(callListener)
        ChatNet.onStatus = { msg ->
            status.text = msg ?: ""
            status.visibility = if (msg == null) View.GONE else View.VISIBLE
        }
        updateCallBar()
        rebuild()
    }

    override fun onStop() {
        ChatNet.removeMessageListener(msgListener)
        ChatNet.removePeersListener(peersListener)
        CallManager.removeListener(callListener)
        ChatNet.onStatus = null
        ChatNet.activityStopped()
        super.onStop()
    }

    private fun rebuild() {
        items.clear()
        items.add(ContactItem("all", "📢 الدردشة العامة", "للجميع على الشبكة", ChatNet.unread["all"] ?: 0))
        val cs = ChatNet.contacts.values.sortedWith(
            compareByDescending<Contact> { ChatNet.isOnline(it.id) }.thenBy { it.name }
        )
        for (c in cs) {
            items.add(ContactItem(c.id, c.name, ChatNet.statusText(c.id), ChatNet.unread[c.id] ?: 0))
        }
        adapter.notifyDataSetChanged()
    }

    private fun openChat(id: String) {
        startActivity(Intent(this, ChatActivity::class.java).putExtra("conv", id))
    }

    private fun confirmDelete(it: ContactItem) {
        if (it.id == "all") return
        AlertDialog.Builder(this)
            .setTitle("حذف ${it.title} من القائمة؟")
            .setMessage("إذا رجع واتصل بالشبكة يظهر من جديد.")
            .setPositiveButton("حذف") { _, _ ->
                ChatNet.forget(it.id)
                rebuild()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun updateCallBar() {
        val n = CallManager.peerName
        val t = when (CallManager.state) {
            CallManager.State.IDLE -> null
            CallManager.State.INCOMING -> "📞 مكالمة واردة من $n — اضغط للرد"
            CallManager.State.OUTGOING -> "📞 جاري الاتصال بـ $n — اضغط للعودة"
            CallManager.State.ACTIVE -> "🟢 مكالمة جارية مع $n — اضغط للعودة"
        }
        callBar.text = t ?: ""
        callBar.visibility = if (t == null) View.GONE else View.VISIBLE
    }

    // ───────────── الصورة الشخصية ─────────────

    private fun avatarFile() = File(filesDir, "avatar.jpg")

    private fun loadAvatar() {
        val f = avatarFile()
        if (f.isFile) {
            try {
                avatarImg.setImageBitmap(circularBitmap(BitmapFactory.decodeFile(f.absolutePath)))
                avatarImg.visibility = View.VISIBLE
                crownText.visibility = View.GONE
            } catch (_: Exception) {
            }
        }
    }

    private fun circularBitmap(src: Bitmap): Bitmap {
        val size = minOf(src.width, src.height)
        val x = (src.width - size) / 2
        val y = (src.height - size) / 2
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        }
        val m = android.graphics.Matrix()
        m.setTranslate(-x.toFloat(), -y.toFloat())
        paint.shader.setLocalMatrix(m)
        c.drawCircle(size / 2f, size / 2f, size / 2f, paint)
        return out
    }

    private fun saveAvatar(uri: Uri) {
        try {
            val cr = contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 600) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return
            FileOutputStream(avatarFile()).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            avatarImg.setImageBitmap(circularBitmap(bmp))
            avatarImg.visibility = View.VISIBLE
            crownText.visibility = View.GONE
            Toast.makeText(this, "تم تغيير الصورة الشخصية", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "تعذّر فتح الصورة", Toast.LENGTH_SHORT).show()
        }
    }

    // ───────────── الاسم والأذونات ─────────────

    private fun ensureName() {
        val prefs = getSharedPreferences("lanchat", MODE_PRIVATE)
        val saved = prefs.getString("name", "") ?: ""
        if (saved.isNotBlank()) {
            begin(saved)
            return
        }
        val box = EditText(this).apply {
            hint = "اكتب اسمك"
            filters = arrayOf(InputFilter.LengthFilter(24))
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("مرحباً 👋")
            .setMessage("اختر اسماً يظهر للآخرين")
            .setView(box)
            .setCancelable(false)
            .setPositiveButton("دخول") { _, _ ->
                val n = box.text.toString().trim().ifEmpty { "مستخدم" + (100..999).random() }
                prefs.edit().putString("name", n).apply()
                begin(n)
            }
            .show()
    }

    private fun begin(name: String) {
        ChatNet.myName = name

        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (!BtServer.hasPerm(this)) need.add(Manifest.permission.BLUETOOTH_CONNECT)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)

        ContextCompat.startForegroundService(this, Intent(this, ChatService::class.java))

        askBatteryOnce()
    }

    /** مرة وحدة: نطلب إيقاف تحسين البطارية حتى ما يقفل النظام التطبيق */
    private fun askBatteryOnce() {
        val prefs = getSharedPreferences("lanchat", MODE_PRIVATE)
        if (prefs.getBoolean("battery_asked", false)) return
        val pm = getSystemService(PowerManager::class.java)
        if (pm != null && pm.isIgnoringBatteryOptimizations(packageName)) {
            askOemOnce()
            return
        }
        prefs.edit().putBoolean("battery_asked", true).apply()
        AlertDialog.Builder(this)
            .setTitle("حتى توصلك الرسائل والمكالمات")
            .setMessage("اسمح للتطبيق يشتغل بالخلفية بدون قيود البطارية، وإلا ممكن النظام يوقفه وتفوتك المكالمات لما تنطفي الشاشة.")
            .setPositiveButton("سماح") { _, _ ->
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                            .setData(Uri.parse("package:$packageName"))
                    )
                } catch (_: Exception) {
                }
            }
            .setNegativeButton("لاحقاً", null)
            .setOnDismissListener { askOemOnce() }
            .show()
    }

    /** تلفونات هواوي/هونر/شاومي... تقتل التطبيق بالخلفية: نشرح للمستخدم مرة وحدة */
    private fun askOemOnce() {
        val prefs = getSharedPreferences("lanchat", MODE_PRIVATE)
        if (prefs.getBoolean("oem_asked", false)) return
        val maker = Build.MANUFACTURER.lowercase()
        val huawei = maker.contains("huawei") || maker.contains("honor")
        val other = maker.contains("xiaomi") || maker.contains("oppo") || maker.contains("vivo") ||
            maker.contains("realme") || maker.contains("oneplus")
        if (!huawei && !other) return
        prefs.edit().putBoolean("oem_asked", true).apply()
        val msg = if (huawei) {
            "حتى يرن التلفون وهو مطفي الشاشة:\n\n" +
                "1) الإعدادات ← البطارية ← تشغيل التطبيقات (Launch)\n" +
                "2) دردشة الشبكة ← إدارة يدوية\n" +
                "3) فعّل الثلاثة: التشغيل التلقائي، التشغيل الثانوي، التشغيل بالخلفية\n\n" +
                "وبالواي فاي: ⋮ ← إعدادات متقدمة ← إبقاء الواي فاي شغال أثناء السكون ← دائماً"
        } else {
            "حتى يرن التلفون وهو مطفي الشاشة، افتح إعدادات التطبيق وفعّل:\n" +
                "التشغيل التلقائي (Autostart) وبدون قيود البطارية."
        }
        AlertDialog.Builder(this)
            .setTitle("خطوة مهمة")
            .setMessage(msg)
            .setPositiveButton("فتح الإعدادات") { _, _ ->
                var opened = false
                if (huawei) {
                    try {
                        startActivity(
                            Intent().setComponent(
                                ComponentName(
                                    "com.huawei.systemmanager",
                                    "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"
                                )
                            )
                        )
                        opened = true
                    } catch (_: Exception) {
                    }
                }
                if (!opened) {
                    try {
                        startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                .setData(Uri.parse("package:$packageName"))
                        )
                    } catch (_: Exception) {
                    }
                }
            }
            .setNegativeButton("لاحقاً", null)
            .show()
    }

    // ───────────── مكالمة بلوتوث ─────────────

    private fun ensureMic(then: () -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            then()
        } else {
            afterMic = then
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
        }
    }

    @SuppressLint("MissingPermission")
    private fun btCallDialog() {
        val ad = BtServer.adapter(this)
        if (ad == null) {
            Toast.makeText(this, "هذا التلفون ما يدعم بلوتوث", Toast.LENGTH_LONG).show()
            return
        }
        if (!BtServer.hasPerm(this)) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 3)
            return
        }
        BtServer.start(this)
        if (!ad.isEnabled) {
            Toast.makeText(this, "شغّل البلوتوث أولاً ثم اضغط بلوتوث", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            } catch (_: Exception) {
            }
            return
        }
        val devs = ad.bondedDevices.toList().sortedBy { it.name ?: "" }
        val names = devs.map { it.name ?: it.address } + "➕ ربط تلفون جديد (مرة وحدة)"
        AlertDialog.Builder(this)
            .setTitle("اتصل بالبلوتوث")
            .setItems(names.toTypedArray()) { _, which ->
                if (which < devs.size) {
                    CallManager.callBt(this, devs[which])
                } else {
                    Toast.makeText(this, "اقرن التلفونين ببعض ثم ارجع واضغط بلوتوث", Toast.LENGTH_LONG).show()
                    try {
                        startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                    } catch (_: Exception) {
                    }
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            BtServer.start(this)
        }
        if (requestCode == 2) {
            val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            val next = afterMic
            afterMic = null
            if (ok) next?.invoke()
            else Toast.makeText(this, "لازم تسمح للميكروفون حتى تتصل", Toast.LENGTH_LONG).show()
        }
        if (requestCode == 3) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                btCallDialog()
            } else {
                Toast.makeText(this, "لازم تسمح للأجهزة القريبة حتى يشتغل البلوتوث", Toast.LENGTH_LONG).show()
            }
        }
    }
}
