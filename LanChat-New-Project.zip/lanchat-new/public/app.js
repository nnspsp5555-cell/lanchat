(() => {
  const $ = id => document.getElementById(id);
  const els = { connection:$('connection'), joinPanel:$('joinPanel'), chatPanel:$('chatPanel'), settingsPanel:$('settingsPanel'), username:$('username'), room:$('room'), joinBtn:$('joinBtn'), leaveBtn:$('leaveBtn'), roomLabel:$('roomLabel'), usersList:$('usersList'), userCount:$('userCount'), messages:$('messages'), messageForm:$('messageForm'), messageInput:$('messageInput'), fileInput:$('fileInput'), uploadPreview:$('uploadPreview'), charCount:$('charCount'), settingsBtn:$('settingsBtn'), closeSettings:$('closeSettings'), wallpaperInput:$('wallpaperInput'), resetWallpaper:$('resetWallpaper'), chatTitle:$('chatTitle'), chatSubtitle:$('chatSubtitle') };
  let socket = null, currentName = '', currentRoom = 'عام', chatType = 'group', privateTo = '', pendingFile = null, seenIds = new Set();
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function setStatus(online) { els.connection.classList.toggle('online', online); els.connection.classList.toggle('offline', !online); els.connection.innerHTML = `<i></i>${online ? 'متصل بالخادم' : 'غير متصل'}`; }
  function showJoin() { els.joinPanel.classList.remove('hidden'); els.chatPanel.classList.add('hidden'); }
  function showChat() { els.joinPanel.classList.add('hidden'); els.chatPanel.classList.remove('hidden'); els.roomLabel.textContent = currentRoom; }
  function send(obj) { if (!socket || socket.readyState !== WebSocket.OPEN) { alert('الاتصال بالخادم غير متاح.'); return false; } socket.send(JSON.stringify(obj)); return true; }
  function connect() {
    if (socket) { try { socket.close(); } catch {} }
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    socket = new WebSocket(`${proto}//${location.host}`);
    setStatus(false);
    socket.addEventListener('open', () => { setStatus(true); send({type:'join', username:currentName, room:currentRoom}); });
    socket.addEventListener('message', event => {
      let data; try { data = JSON.parse(event.data); } catch { return; }
      if (data.type === 'hello') { renderHistory(data.history || []); renderUsers(data.users || []); }
      if (data.type === 'users') renderUsers(data.users || []);
      if (data.type === 'message' && data.message) appendMessage(data.message);
      if (data.type === 'error') alert(data.message || 'حدث خطأ.');
    });
    socket.addEventListener('close', () => setStatus(false));
    socket.addEventListener('error', () => setStatus(false));
  }
  function renderUsers(users) {
    els.userCount.textContent = users.length;
    els.usersList.innerHTML = '';
    users.forEach(name => {
      const row = document.createElement('div'); row.className = 'user-chip';
      const avatar = document.createElement('span'); avatar.className = 'avatar'; avatar.textContent = (name || '?').slice(0,1);
      const label = document.createElement('span'); label.textContent = name + (name === currentName ? ' (أنت)' : '');
      row.append(avatar,label);
      if (name !== currentName) { row.title = 'اضغط لفتح محادثة خاصة'; row.style.cursor = 'pointer'; row.addEventListener('click', () => { chatType='private'; privateTo=name; els.chatTitle.textContent=`محادثة خاصة مع ${name}`; els.chatSubtitle.textContent='الرسائل الخاصة تظهر للطرفين فقط داخل هذه الغرفة'; els.messageInput.focus(); }); }
      els.usersList.appendChild(row);
    });
  }
  function renderHistory(items) { els.messages.innerHTML = ''; seenIds.clear(); items.forEach(appendMessage); if (!items.length) showEmpty(); }
  function showEmpty() { if (!els.messages.children.length) els.messages.innerHTML = '<div class="empty-state"><span>✦</span><b>بداية جديدة</b><p>اكتب أول رسالة وابدأ المحادثة.</p></div>'; }
  function appendMessage(m) {
    if (!m || !m.id || seenIds.has(m.id)) return;
    if (m.chatType === 'private' && m.from !== currentName && m.to !== currentName) return;
    if (m.chatType === 'private' && chatType !== 'private' && m.from !== currentName) return;
    seenIds.add(m.id); const empty = els.messages.querySelector('.empty-state'); if (empty) empty.remove();
    const wrap = document.createElement('article'); wrap.className = 'message' + (m.from === currentName ? ' mine' : '');
    const meta = document.createElement('div'); meta.className = 'message-meta';
    const name = document.createElement('strong'); name.textContent = m.from || 'مستخدم';
    const time = document.createElement('span'); const d = new Date(m.time || Date.now()); time.textContent = d.toLocaleTimeString('ar-IQ',{hour:'2-digit',minute:'2-digit'});
    meta.append(name,time); if (m.chatType === 'private') { const tag = document.createElement('span'); tag.textContent = 'خاص'; meta.append(tag); }
    const bubble = document.createElement('div'); bubble.className='bubble';
    if (m.type === 'file' && m.file) bubble.innerHTML = renderFile(m.file); else bubble.textContent = m.text || '';
    wrap.append(meta,bubble); els.messages.appendChild(wrap); els.messages.scrollTop=els.messages.scrollHeight;
  }
  function renderFile(f) {
    const url = esc(f.url), name = esc(f.name || 'ملف'), mime = String(f.mime || '');
    if (mime.startsWith('image/')) return `<a href="${url}" target="_blank" rel="noopener"><img class="shared-media" src="${url}" alt="${name}" loading="lazy"></a><div>${name}</div>`;
    if (mime.startsWith('video/')) return `<video class="shared-media" controls preload="metadata" src="${url}"></video><div>${name}</div>`;
    if (mime.startsWith('audio/')) return `<audio controls preload="metadata" src="${url}" style="max-width:100%"></audio><div>${name}</div>`;
    return `<a class="file-card" href="${url}" target="_blank" rel="noopener" download><span class="file-icon">📄</span><span>${name}<small>اضغط لفتح الملف أو تنزيله</small></span></a>`;
  }
  els.joinBtn.addEventListener('click', () => {
    currentName = els.username.value.trim().slice(0,32); currentRoom = els.room.value.trim().slice(0,40) || 'عام';
    if (!currentName) { alert('اكتب اسم المستخدم أولاً.'); els.username.focus(); return; }
    chatType='group'; privateTo=''; els.chatTitle.textContent='المحادثة العامة'; els.chatSubtitle.textContent='الرسائل تظهر للأعضاء في الغرفة'; showChat(); connect();
  });
  els.leaveBtn.addEventListener('click', () => { if (socket) socket.close(); showJoin(); });
  els.messageForm.addEventListener('submit', async e => {
    e.preventDefault();
    if (pendingFile) { await uploadFile(pendingFile); return; }
    const text = els.messageInput.value.trim(); if (!text) return;
    if (send({type:'send', text, chatType, to:privateTo})) { els.messageInput.value=''; els.charCount.textContent='0/2000'; els.messageInput.style.height='44px'; }
  });
  els.messageInput.addEventListener('input', () => { els.charCount.textContent=`${els.messageInput.value.length}/2000`; els.messageInput.style.height='auto'; els.messageInput.style.height=Math.min(130,els.messageInput.scrollHeight)+'px'; });
  els.messageInput.addEventListener('keydown', e => { if (e.key==='Enter' && !e.shiftKey) { e.preventDefault(); els.messageForm.requestSubmit(); } });
  els.fileInput.addEventListener('change', () => { const f=els.fileInput.files && els.fileInput.files[0]; if (!f) return; if (f.size > 40*1024*1024) { alert('الحد الأعلى للملف 40 ميغابايت.'); els.fileInput.value=''; return; } pendingFile=f; els.uploadPreview.textContent=`الملف المختار: ${f.name} — اضغط إرسال لرفعه`; els.uploadPreview.classList.remove('hidden'); els.messageInput.placeholder='اضغط إرسال لمشاركة الملف'; });
  async function uploadFile(file) {
    const fd=new FormData(); fd.append('file',file);
    els.uploadPreview.textContent='جاري رفع الملف…';
    try {
      const response=await fetch('/api/upload',{method:'POST',body:fd}); const data=await response.json();
      if (!response.ok) throw new Error(data.error || 'فشل رفع الملف');
      if (send({type:'file',file:data,chatType,to:privateTo})) { pendingFile=null; els.fileInput.value=''; els.uploadPreview.classList.add('hidden'); els.messageInput.placeholder='اكتب رسالتك هنا...'; }
    } catch(err) { alert(err.message || 'تعذر رفع الملف.'); els.uploadPreview.textContent='تعذر رفع الملف. حاول مرة ثانية.'; }
  }
  els.settingsBtn.addEventListener('click',()=>{els.settingsPanel.classList.remove('hidden');els.joinPanel.classList.add('hidden');els.chatPanel.classList.add('hidden');});
  els.closeSettings.addEventListener('click',()=>{els.settingsPanel.classList.add('hidden');if(socket&&socket.readyState===WebSocket.OPEN)showChat();else showJoin();});
  document.querySelectorAll('.swatch').forEach(btn=>btn.addEventListener('click',()=>{const theme=btn.dataset.theme;document.body.dataset.theme=theme==='dark'?'':theme;localStorage.setItem('lanchat-theme',theme);}));
  const savedTheme=localStorage.getItem('lanchat-theme');if(savedTheme)document.body.dataset.theme=savedTheme==='dark'?'':savedTheme;
  els.wallpaperInput.addEventListener('change',()=>{const f=els.wallpaperInput.files&&els.wallpaperInput.files[0];if(!f)return;if(!f.type.startsWith('image/')){alert('اختار صورة فقط.');return;}if(f.size>8*1024*1024){alert('الصورة لازم تكون أقل من 8 ميغابايت.');return;}const reader=new FileReader();reader.onload=()=>{localStorage.setItem('lanchat-wallpaper',reader.result);document.documentElement.style.setProperty('--wallpaper',`url("${reader.result}")`);};reader.readAsDataURL(f);});
  els.resetWallpaper.addEventListener('click',()=>{localStorage.removeItem('lanchat-wallpaper');document.documentElement.style.setProperty('--wallpaper','none');els.wallpaperInput.value='';});
  const wallpaper=localStorage.getItem('lanchat-wallpaper');if(wallpaper)document.documentElement.style.setProperty('--wallpaper',`url("${wallpaper}")`);
})();
