import React, { useRef, useEffect, useState } from 'react';
import {
  Users,
  Smartphone,
  Laptop,
  Tablet,
  Search,
  ArrowDown,
  X,
  Zap,
  Info,
  Sparkles,
} from 'lucide-react';
import {
  ChatMessage,
  User,
  AccentColor,
  ReplyContext,
  ThemeSettings,
} from '../types/chat';
import { MessageItem } from './MessageItem';
import { ChatInput } from './ChatInput';

interface ChatAreaProps {
  activeChatId: string;
  currentUser: User | null;
  targetPeer: User | null;
  onlineCount: number;
  messages: ChatMessage[];
  typingUsers: { id: string; name: string }[];
  settings: ThemeSettings;
  onSendMessage: (params: {
    content: string;
    mediaType?: 'text' | 'image' | 'video' | 'audio' | 'file';
    fileUrl?: string;
    fileName?: string;
    fileSize?: number;
    fileMime?: string;
  }) => void;
  onTyping: (isTyping: boolean) => void;
  onSendNudge: (targetId: string) => void;
  onOpenImage: (url: string, fileName?: string) => void;
  onRecordSoundFeedback: () => void;
  isSearching: boolean;
  onCloseSearch: () => void;
}

export const ChatArea: React.FC<ChatAreaProps> = ({
  activeChatId,
  currentUser,
  targetPeer,
  onlineCount,
  messages,
  typingUsers,
  settings,
  onSendMessage,
  onTyping,
  onSendNudge,
  onOpenImage,
  onRecordSoundFeedback,
  isSearching,
  onCloseSearch,
}) => {
  const [replyTo, setReplyTo] = useState<ReplyContext | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showScrollBottom, setShowScrollBottom] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);

  const isPublic = activeChatId === 'public';

  // Filter messages based on search query
  const filteredMessages = searchQuery.trim()
    ? messages.filter((m) =>
        m.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.senderName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (m.fileName && m.fileName.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : messages;

  // Auto scroll to bottom
  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };

  useEffect(() => {
    scrollToBottom('auto');
  }, [activeChatId]);

  useEffect(() => {
    // Only auto scroll if user is near bottom
    const container = scrollContainerRef.current;
    if (container) {
      const isNearBottom =
        container.scrollHeight - container.scrollTop - container.clientHeight < 160;
      if (isNearBottom) {
        scrollToBottom('smooth');
      }
    }
  }, [messages.length]);

  const handleScroll = () => {
    const container = scrollContainerRef.current;
    if (container) {
      const isUp = container.scrollHeight - container.scrollTop - container.clientHeight > 220;
      setShowScrollBottom(isUp);
    }
  };

  const handleReplyMessage = (msg: ChatMessage) => {
    setReplyTo({
      id: msg.id,
      senderName: msg.senderName,
      content: msg.content,
      mediaType: msg.mediaType,
    });
  };

  // Font size classes
  const fontSizes = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base',
  };

  // Background pattern classes
  const patternClasses = {
    none: '',
    dots: 'chat-pattern-dots',
    grid: 'chat-pattern-grid',
    waves: 'chat-pattern-waves',
  };

  return (
    <div
      className={`flex-1 flex flex-col h-full overflow-hidden relative ${patternClasses[settings.pattern]}`}
    >
      {/* Chat Area Header */}
      <div className="h-14 border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-md px-3 sm:px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          {isPublic ? (
            <>
              <div className="w-9 h-9 rounded-xl bg-cyan-600/20 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shrink-0">
                <Users size={18} />
              </div>
              <div className="min-w-0">
                <h3 className="font-bold text-xs sm:text-sm text-slate-100 truncate">
                  الغرفة العامة (Public)
                </h3>
                <p className="text-[11px] text-slate-400 truncate">
                  محادثة مفتوحة لجميع أجهزة الشبكة • {onlineCount} متصل
                </p>
              </div>
            </>
          ) : (
            <>
              <div className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-base shrink-0">
                {targetPeer?.avatar || '👤'}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 font-bold text-xs sm:text-sm text-slate-100 truncate">
                  <span className="truncate">{targetPeer?.name || 'مستخدم غير متصل'}</span>
                  {targetPeer && (
                    <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                  )}
                </div>
                <div className="text-[11px] text-slate-400 font-mono truncate flex items-center gap-2">
                  <span>{targetPeer?.ip || 'IP غير متاح'}</span>
                  {targetPeer?.status && (
                    <span className="text-[10px] text-cyan-400">
                      • {targetPeer.status === 'online' ? 'متصل' : targetPeer.status === 'busy' ? 'مشغول' : 'بعيد'}
                    </span>
                  )}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Header Right Action: Buzz / Nudge */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onSendNudge(activeChatId)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-semibold transition-all cursor-pointer"
            title="إرسال تنبيه واهتزاز إلى الطرف الآخر"
          >
            <Zap size={13} className="text-amber-400" />
            <span className="hidden sm:inline">نكز / تنبيه</span>
          </button>
        </div>
      </div>

      {/* In-Chat Search Bar */}
      {isSearching && (
        <div className="bg-slate-900 border-b border-slate-800 p-2 px-3 flex items-center justify-between gap-2 animate-in slide-in-from-top-2">
          <div className="flex items-center gap-2 flex-1">
            <Search size={15} className="text-slate-400 shrink-0" />
            <input
              type="text"
              autoFocus
              placeholder="ابحث في رسائل هذه المحادثة..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent text-xs text-slate-100 placeholder-slate-500 outline-none w-full"
            />
          </div>
          {searchQuery && (
            <span className="text-[10px] text-slate-400 font-mono">
              {filteredMessages.length} نتيجة
            </span>
          )}
          <button
            onClick={() => {
              setSearchQuery('');
              onCloseSearch();
            }}
            className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
          >
            <X size={15} />
          </button>
        </div>
      )}

      {/* Messages Scroll Container */}
      <div
        ref={scrollContainerRef}
        onScroll={handleScroll}
        className={`flex-1 overflow-y-auto p-3 sm:p-4 space-y-1 ${fontSizes[settings.fontSize]}`}
      >
        {/* Empty State */}
        {filteredMessages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3 select-none">
            <div className="w-14 h-14 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-center text-cyan-400 shadow-xl">
              <Sparkles size={26} />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-200">
                {isPublic ? 'مرحباً بك في الغرفة العامة!' : `محادثة خاصة مع ${targetPeer?.name || 'المستخدم'}`}
              </h4>
              <p className="text-xs text-slate-400 max-w-xs mt-1 leading-relaxed">
                {isPublic
                  ? 'يمكنك إرسال الرسائل والصور والمقاطع الصوتية والملفات إلى كل من هو متصل بنفس شبكة Wi-Fi.'
                  : 'هذه المحادثة خاصة بينكما فقط وتُنقل مباشرة عبر شبكة Wi-Fi المحلية دون المرور بالإنترنت.'}
              </p>
            </div>

            {/* Quick Starters */}
            <div className="flex flex-wrap justify-center gap-2 pt-2">
              {[
                'سلام عليكم ورحمة الله 👋',
                'مرحباً، هل الصوت والصورة واضحة؟',
                'أنا متصل عبر شبكة Wi-Fi المحلية 📱',
              ].map((starter) => (
                <button
                  key={starter}
                  onClick={() => onSendMessage({ content: starter, mediaType: 'text' })}
                  className="px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-cyan-400 text-xs transition-colors cursor-pointer"
                >
                  {starter}
                </button>
              ))}
            </div>
          </div>
        ) : (
          filteredMessages.map((msg) => {
            const isSelf = msg.senderId === currentUser?.id;
            return (
              <MessageItem
                key={msg.id}
                message={msg}
                isSelf={isSelf}
                accent={settings.accent}
                onReply={handleReplyMessage}
                onOpenImage={onOpenImage}
              />
            );
          })
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Typing indicator */}
      {typingUsers.length > 0 && (
        <div className="px-4 py-1 text-[11px] text-cyan-400 flex items-center gap-1.5 bg-slate-950/60 border-t border-slate-900 select-none animate-pulse">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
          <span>
            {typingUsers.map((u) => u.name).join('، ')} يكتب الآن... ✍️
          </span>
        </div>
      )}

      {/* Floating Scroll to Bottom Button */}
      {showScrollBottom && (
        <button
          onClick={() => scrollToBottom('smooth')}
          className="absolute bottom-20 left-4 p-2.5 rounded-full bg-cyan-600 hover:bg-cyan-500 text-white shadow-xl transition-all cursor-pointer z-20 animate-in fade-in"
          title="الانتقال لآخر الرسائل"
        >
          <ArrowDown size={18} />
        </button>
      )}

      {/* Chat Input */}
      <ChatInput
        accent={settings.accent}
        replyTo={replyTo}
        onCancelReply={() => setReplyTo(null)}
        onSendMessage={(params) => {
          onSendMessage(params);
          setReplyTo(null);
        }}
        onTyping={onTyping}
        onRecordSoundFeedback={onRecordSoundFeedback}
      />
    </div>
  );
};
