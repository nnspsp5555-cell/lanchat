import React from 'react';
import { X, Download, ZoomIn, ZoomOut, RotateCw } from 'lucide-react';

interface MediaLightboxProps {
  imageUrl: string | null;
  fileName?: string;
  onClose: () => void;
}

export const MediaLightbox: React.FC<MediaLightboxProps> = ({ imageUrl, fileName, onClose }) => {
  const [scale, setScale] = React.useState(1);
  const [rotation, setRotation] = React.useState(0);

  if (!imageUrl) return null;

  const handleZoomIn = () => setScale((s) => Math.min(s + 0.25, 3));
  const handleZoomOut = () => setScale((s) => Math.max(s - 0.25, 0.5));
  const handleRotate = () => setRotation((r) => (r + 90) % 360);

  return (
    <div
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col items-center justify-between p-4 select-none animate-in fade-in duration-200"
      onClick={onClose}
    >
      {/* Top Header */}
      <div
        className="w-full flex items-center justify-between text-white max-w-4xl z-10"
        onClick={(e) => e.stopPropagation()}
      >
        <span className="text-sm font-medium truncate max-w-md text-slate-200">
          {fileName || 'صورة'}
        </span>

        <div className="flex items-center gap-2">
          <button
            onClick={handleZoomOut}
            className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 transition-colors"
            title="تصغير"
          >
            <ZoomOut size={18} />
          </button>
          <button
            onClick={handleZoomIn}
            className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 transition-colors"
            title="تكبير"
          >
            <ZoomIn size={18} />
          </button>
          <button
            onClick={handleRotate}
            className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 transition-colors"
            title="تدوير"
          >
            <RotateCw size={18} />
          </button>
          <a
            href={imageUrl}
            download={fileName || 'image.png'}
            className="p-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white transition-colors"
            title="تحميل الصورة"
          >
            <Download size={18} />
          </a>
          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-slate-800/80 hover:bg-rose-600 text-white transition-colors mr-2"
            title="إغلاق"
          >
            <X size={18} />
          </button>
        </div>
      </div>

      {/* Image container */}
      <div
        className="flex-1 flex items-center justify-center w-full overflow-hidden my-2"
        onClick={(e) => e.stopPropagation()}
      >
        <img
          src={imageUrl}
          alt={fileName || 'صورة مكبرة'}
          style={{
            transform: `scale(${scale}) rotate(${rotation}deg)`,
            transition: 'transform 0.2s cubic-bezier(0.2, 0, 0.2, 1)',
          }}
          className="max-h-[85vh] max-w-[90vw] object-contain rounded-lg shadow-2xl cursor-grab active:cursor-grabbing"
        />
      </div>

      {/* Bottom hint */}
      <div className="text-xs text-slate-400 pb-2">
        انقر في أي مكان فارغ للإغلاق • نسبة التكبير: {Math.round(scale * 100)}%
      </div>
    </div>
  );
};
