package com.example.lanchat

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.net.ServerSocket
import java.net.Socket
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.concurrent.thread

data class ChatMessage(
    val id: String,
    val name: String,
    val text: String,
    val time: Long,
    val mine: Boolean,
    val kind: String = "text",      // text | image | file
    val fileName: String = "",
    val size: Long = 0,
    var path: String = "",          // مكان الملف على هذا الجهاز (فارغ = لسا ما نزل)
    var progress: Int = 0,
    var failed: Boolean = false,
    val ip: String = ""             // عنوان المرسل لتحميل الملف منه
)

/**
 * شبكة الدردشة: بدون سيرفر. كل جهاز يرسل الرسائل بـ UDP Broadcast على الشبكة المحلية
 * ويستمع على نفس المنفذ، وكل جهاز يعلن عن نفسه كل 4 ثواني ليظهر في قائمة المتصلين.
 */
data class Peer(val id: String, val name: String, val ip: String, val seen: Long)

object ChatNet {
    const val PORT = 45454
    const val MAX_LEN = 500
    const val FILE_PORT = 45456
    const val MAX_FILE = 50L * 1024 * 1024
    private const val PEER_TIMEOUT = 15_000L

    val deviceId = UUID.randomUUID().toString().take(8)
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var myName: String = ""

    // تُقرأ وتُعدَّل على الخيط الرئيسي فقط
    val messages = ArrayList<ChatMessage>()
    private val seen = HashSet<String>()

    private val peers = ConcurrentHashMap<String, Peer>()

    var onMessage: ((ChatMessage) -> Unit)? = null
    var onIncoming: ((ChatMessage) -> Unit)? = null   // رسالة واردة من غيري (للإشعارات)

    @Volatile
    var appVisible: Boolean = false
    var onPeers: ((List<String>) -> Unit)? = null
    var onStatus: ((String?) -> Unit)? = null
    var onUpdate: ((ChatMessage) -> Unit)? = null   // تحديث رسالة موجودة (تقدم تحميل ملف)

    private lateinit var appCtx: Context
    private var wlock: WifiManager.WifiLock? = null
    @Volatile
    private var server: ServerSocket? = null
    private val dl = Executors.newFixedThreadPool(3)

    @Volatile
    private var socket: DatagramSocket? = null
    private var lock: WifiManager.MulticastLock? = null
    private var sender = Executors.newSingleThreadExecutor()

    @Volatile
    private var running = false

    @Synchronized
    fun start(ctx: Context) {
        if (running) return
        running = true
        appCtx = ctx.applicationContext
        try {
            val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            lock = wifi.createMulticastLock("lanchat").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {
        }
        try {
            val w = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wlock = w.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "lanchat-wifi").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {
        }
        sender = Executors.newSingleThreadExecutor()
        thread(name = "lanchat-files", isDaemon = true) { serveLoop() }
        thread(name = "lanchat-clean", isDaemon = true) { cleanOld() }
        thread(name = "lanchat-rx", isDaemon = true) { receiveLoop() }
        thread(name = "lanchat-hb", isDaemon = true) { heartbeatLoop() }
    }

    @Synchronized
    fun stop() {
        running = false
        try {
            socket?.close()
        } catch (_: Exception) {
        }
        socket = null
        try {
            lock?.release()
        } catch (_: Exception) {
        }
        lock = null
        try {
            wlock?.release()
        } catch (_: Exception) {
        }
        wlock = null
        try {
            server?.close()
        } catch (_: Exception) {
        }
        server = null
        sender.shutdownNow()
        peers.clear()
    }

    /** يُستدعى من الخيط الرئيسي */
    fun send(text: String) {
        val t = text.trim().take(MAX_LEN)
        if (t.isEmpty() || myName.isEmpty()) return
        val now = System.currentTimeMillis()
        val id = "$deviceId-$now-${(0..9999).random()}"
        val m = ChatMessage(id, myName, t, now, true)
        seen.add(id)
        messages.add(m)
        onMessage?.invoke(m)

        val json = JSONObject()
            .put("t", "msg").put("d", deviceId).put("i", id)
            .put("n", myName).put("x", t).put("ts", now)
            .toString()
        sendRaw(json, 2) // مرتين لتقليل ضياع الحزم، والتكرار يُحذف بالـ id
    }

    private fun sendRaw(json: String, times: Int) {
        val bytes = json.toByteArray(Charsets.UTF_8)
        try {
            sender.execute {
                repeat(times) { n ->
                    val s = socket
                    if (s != null) {
                        for (addr in targets()) {
                            try {
                                s.send(DatagramPacket(bytes, bytes.size, addr, PORT))
                            } catch (_: Exception) {
                            }
                        }
                    }
                    if (n < times - 1) nap(150)
                }
            }
        } catch (_: Exception) {
        }
    }

    // ───────────── الصور والملفات (TCP مباشر بين الجهازين) ─────────────

    private fun outDir() = File(appCtx.filesDir, "outgoing").apply { mkdirs() }
    private fun inDir() = File(appCtx.filesDir, "received").apply { mkdirs() }

    private fun cleanOld() {
        try {
            val limit = System.currentTimeMillis() - 3L * 24 * 3600 * 1000
            for (d in listOf(outDir(), inDir())) {
                d.listFiles()?.forEach { if (it.lastModified() < limit) it.delete() }
            }
        } catch (_: Exception) {
        }
    }

    private fun serveLoop() {
        while (running) {
            val ss: ServerSocket = server?.takeIf { !it.isClosed } ?: try {
                ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress(FILE_PORT))
                }.also { server = it }
            } catch (_: Exception) {
                nap(3000)
                continue
            }
            try {
                val c = ss.accept()
                thread(name = "lanchat-serve", isDaemon = true) { serveOne(c) }
            } catch (_: Exception) {
                if (running) nap(300)
            }
        }
    }

    private fun readLine(inp: InputStream): String {
        val sb = StringBuilder()
        while (sb.length < 100) {
            val b = inp.read()
            if (b < 0 || b == '\n'.code) break
            sb.append(b.toChar())
        }
        return sb.toString()
    }

    private fun serveOne(c: Socket) {
        try {
            c.soTimeout = 15000
            val id = readLine(c.getInputStream()).removePrefix("GET ").trim()
                .filter { it.isLetterOrDigit() || it == '-' }
            val f = File(outDir(), id)
            val out = DataOutputStream(BufferedOutputStream(c.getOutputStream(), 64 * 1024))
            if (id.isEmpty() || !f.isFile) {
                out.writeLong(-1)
                out.flush()
                return
            }
            out.writeLong(f.length())
            FileInputStream(f).use { it.copyTo(out, 64 * 1024) }
            out.flush()
        } catch (_: Exception) {
        } finally {
            try {
                c.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun safeName(n: String): String {
        val x = n.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_").take(80)
        return if (x.isBlank()) "file" else x
    }

    /** يُستدعى من الخيط الرئيسي */
    fun startDownload(m: ChatMessage) {
        if (m.size > MAX_FILE) {
            m.failed = true
            return
        }
        m.failed = false
        m.progress = 0
        dl.execute {
            var ok = false
            val dest = File(inDir(), m.id + "_" + safeName(m.fileName))
            try {
                Socket().use { s ->
                    s.connect(InetSocketAddress(m.ip, FILE_PORT), 5000)
                    s.soTimeout = 15000
                    val os = s.getOutputStream()
                    os.write(("GET " + m.id + "\n").toByteArray())
                    os.flush()
                    val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 64 * 1024))
                    val len = inp.readLong()
                    if (len in 0..MAX_FILE) {
                        FileOutputStream(dest).use { fo ->
                            val buf = ByteArray(64 * 1024)
                            var got = 0L
                            var last = -1
                            while (got < len) {
                                val n = inp.read(buf, 0, minOf(buf.size.toLong(), len - got).toInt())
                                if (n < 0) break
                                fo.write(buf, 0, n)
                                got += n
                                val pct = (got * 100 / maxOf(len, 1L)).toInt()
                                if (pct != last) {
                                    last = pct
                                    m.progress = pct
                                    main.post { onUpdate?.invoke(m) }
                                }
                            }
                            ok = got == len
                        }
                    }
                }
            } catch (_: Exception) {
            }
            if (ok) {
                m.path = dest.absolutePath
                m.progress = 100
                m.failed = false
            } else {
                m.failed = true
                dest.delete()
            }
            main.post { onUpdate?.invoke(m) }
        }
    }

    fun retry(m: ChatMessage) {
        if (m.path.isNotEmpty()) return
        startDownload(m)
        onUpdate?.invoke(m)
    }

    private fun queryName(cr: ContentResolver, uri: Uri): String? {
        return try {
            cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun compressImage(cr: ContentResolver, uri: Uri, dest: File): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            val side = maxOf(bounds.outWidth, bounds.outHeight)
            while (side / sample > 2000) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false
            val orient = try {
                cr.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
                } ?: 1
            } catch (_: Exception) {
                1
            }
            val deg = when (orient) {
                6 -> 90f
                3 -> 180f
                8 -> 270f
                else -> 0f
            }
            val fin = if (deg != 0f) {
                Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
            } else bmp
            dest.outputStream().use { fin.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            true
        } catch (_: Exception) {
            false
        }
    }

    /** يُستدعى من الخيط الرئيسي: ينسخ الملف ثم يعلن عنه للجميع */
    fun sendFile(ctx: Context, uri: Uri, asImage: Boolean) {
        if (myName.isEmpty()) return
        val app = ctx.applicationContext
        appCtx = app
        thread(name = "lanchat-prep", isDaemon = true) {
            val now = System.currentTimeMillis()
            val id = "$deviceId-$now-${(0..9999).random()}"
            val dest = File(outDir(), id)
            try {
                val cr = app.contentResolver
                var name = queryName(cr, uri) ?: if (asImage) "image.jpg" else "file"
                var kind = "file"
                if (asImage && compressImage(cr, uri, dest)) {
                    kind = "image"
                    name = name.substringBeforeLast('.') + ".jpg"
                }
                if (kind == "file") {
                    val inp = cr.openInputStream(uri) ?: throw Exception("open")
                    inp.use { i ->
                        dest.outputStream().use { o ->
                            val buf = ByteArray(64 * 1024)
                            var total = 0L
                            while (true) {
                                val n = i.read(buf)
                                if (n < 0) break
                                total += n
                                if (total > MAX_FILE) throw Exception("big")
                                o.write(buf, 0, n)
                            }
                        }
                    }
                }
                val size = dest.length()
                val label = if (kind == "image") "📷 صورة" else "📎 $name"
                val finalKind = kind
                val finalName = name
                main.post {
                    val m = ChatMessage(id, myName, label, now, true, finalKind, finalName, size, dest.absolutePath, 100)
                    seen.add(id)
                    messages.add(m)
                    onMessage?.invoke(m)
                }
                val json = JSONObject()
                    .put("t", "file").put("d", deviceId).put("i", id).put("n", myName)
                    .put("fn", finalName).put("sz", size).put("k", finalKind).put("ts", now)
                    .toString()
                sendRaw(json, 2)
            } catch (e: Exception) {
                dest.delete()
                main.post {
                    Toast.makeText(app, "تعذّر إرسال الملف (الحد الأقصى 50MB)", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun helloJson(): String =
        JSONObject().put("t", "hello").put("d", deviceId).put("n", myName).toString()

    /** زر التحديث: يعيد فتح المنفذ ويمسح القائمة ويعلن عن نفسه فوراً */
    fun refresh() {
        peers.clear()
        try {
            socket?.close() // حلقة الاستقبال تفتح منفذ جديد لحالها
        } catch (_: Exception) {
        }
        main.postDelayed({
            if (myName.isNotEmpty()) sendRaw(helloJson(), 2)
        }, 700)
    }

    /** قائمة المتصلين حالياً (مع عناوينهم) */
    fun peerList(): List<Peer> {
        val now = System.currentTimeMillis()
        return peers.values.filter { now - it.seen <= PEER_TIMEOUT }.sortedBy { it.name }
    }

    /** إرسال رسالة تحكم لجهاز واحد بالعنوان المباشر (للمكالمات) */
    fun sendTo(ip: String, json: String, times: Int) {
        val bytes = json.toByteArray(Charsets.UTF_8)
        try {
            sender.execute {
                val addr = try {
                    InetAddress.getByName(ip)
                } catch (_: Exception) {
                    null
                }
                if (addr == null) return@execute
                repeat(times) { n ->
                    try {
                        socket?.send(DatagramPacket(bytes, bytes.size, addr, PORT))
                    } catch (_: Exception) {
                    }
                    if (n < times - 1) nap(150)
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun targets(): Set<InetAddress> {
        val out = LinkedHashSet<InetAddress>()
        try {
            NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { ni ->
                if (ni.isUp && !ni.isLoopback) {
                    ni.interfaceAddresses.forEach { ia -> ia.broadcast?.let { out.add(it) } }
                }
            }
        } catch (_: Exception) {
        }
        try {
            out.add(InetAddress.getByName("255.255.255.255"))
        } catch (_: Exception) {
        }
        return out
    }

    private fun receiveLoop() {
        val buf = ByteArray(4096)
        while (running) {
            var s = socket
            if (s == null || s.isClosed) {
                try {
                    s = DatagramSocket(null).apply {
                        reuseAddress = true
                        broadcast = true
                        bind(InetSocketAddress(PORT))
                    }
                    socket = s
                    main.post { onStatus?.invoke(null) }
                } catch (_: Exception) {
                    main.post { onStatus?.invoke("تعذّر فتح المنفذ، تأكد من الاتصال بالواي فاي") }
                    nap(3000)
                    continue
                }
            }
            try {
                val p = DatagramPacket(buf, buf.size)
                s!!.receive(p)
                handle(String(p.data, 0, p.length, Charsets.UTF_8), p.address?.hostAddress ?: "")
            } catch (_: Exception) {
                if (running) nap(300)
            }
        }
    }

    private fun handle(raw: String, ip: String) {
        val o = try {
            JSONObject(raw)
        } catch (_: Exception) {
            return
        }
        val d = o.optString("d")
        if (d.isEmpty() || d == deviceId) return // تجاهل رسائلي أنا
        val n = o.optString("n").take(24)
        if (n.isNotEmpty() && ip.isNotEmpty()) peers[d] = Peer(d, n, ip, System.currentTimeMillis())

        when (o.optString("t")) {
            "msg" -> {
                val id = o.optString("i")
                val x = o.optString("x").take(MAX_LEN)
                if (id.isNotEmpty() && x.isNotEmpty() && n.isNotEmpty()) {
                    val ts = o.optLong("ts", System.currentTimeMillis())
                    main.post {
                        if (seen.add(id)) {
                            val m = ChatMessage(id, n, x, ts, false)
                            messages.add(m)
                            onMessage?.invoke(m)
                            onIncoming?.invoke(m)
                        }
                    }
                }
            }
            "file" -> {
                val id = o.optString("i")
                val fn = o.optString("fn").take(120)
                val sz = o.optLong("sz", 0)
                val k = if (o.optString("k") == "image") "image" else "file"
                val ts = o.optLong("ts", System.currentTimeMillis())
                if (id.isNotEmpty() && fn.isNotEmpty() && n.isNotEmpty() && ip.isNotEmpty()) {
                    main.post {
                        if (seen.add(id)) {
                            val label = if (k == "image") "📷 صورة" else "📎 $fn"
                            val m = ChatMessage(id, n, label, ts, false, k, fn, sz, "", 0, false, ip)
                            messages.add(m)
                            onMessage?.invoke(m)
                            onIncoming?.invoke(m)
                            startDownload(m)
                        }
                    }
                }
            }
            "call", "acc", "end", "busy" -> {
                val c = o.optString("c")
                val t = o.optString("t")
                if (c.isNotEmpty()) main.post { CallManager.onSignal(t, c, d, n, ip) }
            }
        }
        publishPeers()
    }

    private fun publishPeers() {
        val now = System.currentTimeMillis()
        peers.entries.removeIf { now - it.value.seen > PEER_TIMEOUT }
        val names = peers.values.map { it.name }.distinct().sorted()
        main.post { onPeers?.invoke(names) }
    }

    private fun heartbeatLoop() {
        while (running) {
            if (myName.isNotEmpty()) {
                val hello = JSONObject().put("t", "hello").put("d", deviceId).put("n", myName).toString()
                sendRaw(hello, 1)
            }
            publishPeers()
            nap(4000)
        }
    }

    private fun nap(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }
}
