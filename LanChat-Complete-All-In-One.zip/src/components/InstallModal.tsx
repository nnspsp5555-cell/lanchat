import React from 'react';
import { X, Smartphone, Download, Check, Sparkles, MoreVertical } from 'lucide-react';

interface InstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  deferredPrompt: any;
  onInstallNative: () => void;
}

export const InstallModal: React.FC<InstallModalProps> = ({
  isOpen,
  onClose,
  deferredPrompt,
  onInstallNative,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-md shadow-2xl p-5 flex flex-col gap-4 text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-cyan-500/20 text-cyan-400">
              <Smartphone size={22} />
            </div>
            <div>
              <h2 className="font-bold text-base">تثبيت التطبيق على جهازك</h2>
              <p className="text-xs text-slate-400">أسهل طريقة بدون متجر وبدون برامج</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Native 1-Click Install Button if supported */}
        {deferredPrompt && (
          <div className="bg-gradient-to-r from-cyan-950/60 to-blue-950/60 border border-cyan-500/40 rounded-2xl p-4 text-center space-y-2.5">
            <Sparkles size={24} className="mx-auto text-cyan-400 animate-bounce" />
            <h3 className="font-bold text-sm text-cyan-200">هاتفك يدعم التثبيت الفوري بضغطة واحدة!</h3>
            <button
              onClick={onInstallNative}
              className="w-full py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 transition-transform active:scale-95 shadow-xl cursor-pointer"
            >
              <Download size={18} />
              <span>اضغط هنا لتثبيت التطبيق الآن 📲</span>
            </button>
          </div>
        )}

        {/* Visual 3-Step Guide for all phones */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold text-slate-300">
            خطوات التثبيت من متصفح الهاتف (Chrome):
          </h4>

          <div className="space-y-2">
            <div className="flex items-start gap-3 bg-slate-950/60 border border-slate-800 p-2.5 rounded-xl text-xs">
              <div className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center shrink-0">
                1
              </div>
              <div className="leading-relaxed">
                اضغط على زر خيارات المتصفح <strong className="text-cyan-300 inline-flex items-center gap-0.5 mx-1 font-mono">(⋮)</strong> في أعلى شاشة الهاتف.
              </div>
            </div>

            <div className="flex items-start gap-3 bg-slate-950/60 border border-slate-800 p-2.5 rounded-xl text-xs">
              <div className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center shrink-0">
                2
              </div>
              <div className="leading-relaxed">
                اختر <strong className="text-emerald-400">«تثبيت التطبيق» (Install App)</strong> أو <strong className="text-emerald-400">«إضافة إلى الشاشة الرئيسية»</strong>.
              </div>
            </div>

            <div className="flex items-start gap-3 bg-slate-950/60 border border-slate-800 p-2.5 rounded-xl text-xs">
              <div className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center shrink-0">
                3
              </div>
              <div className="leading-relaxed">
                اضغط <strong className="text-slate-100">«تثبيت»</strong>؛ وستنزل أيقونة التطبيق فوراً على شاشة هاتفك وتفتحه مثل أي تطبيق أصلي!
              </div>
            </div>
          </div>
        </div>

        {/* Advantages */}
        <div className="bg-slate-950/40 p-3 rounded-2xl border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
          <div className="flex items-center gap-1.5 text-slate-300 font-semibold">
            <Check size={14} className="text-emerald-400" />
            <span>يعمل بدون متجر بلاي وبدون ملفات APK معقدة</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300 font-semibold">
            <Check size={14} className="text-emerald-400" />
            <span>حجمه خفيف جداً ولا يستهلك ذاكرة الهاتف</span>
          </div>
        </div>

        {/* Footer */}
        <button
          onClick={onClose}
          className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
        >
          فهمت، شكراً
        </button>
      </div>
    </div>
  );
};
