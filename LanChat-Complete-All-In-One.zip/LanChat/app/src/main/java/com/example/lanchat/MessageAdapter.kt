package com.example.lanchat

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class MessageAdapter(private val messages: MutableList<NetMessage>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val TYPE_ME = 1
        const val TYPE_OTHER = 2
    }

    override fun getItemViewType(position: Int): Int {
        return if (messages[position].isMe) TYPE_ME else TYPE_OTHER
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_ME) {
            val view = inflater.inflate(R.layout.item_message, parent, false)
            MeViewHolder(view)
        } else {
            val view = inflater.inflate(R.layout.item_message, parent, false)
            OtherViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val msg = messages[position]
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val formattedTime = timeFormat.format(Date(msg.timestamp))

        val txtContent = holder.itemView.findViewById<TextView>(R.id.txtContent)
        val txtSender = holder.itemView.findViewById<TextView>(R.id.txtSender)
        val txtTime = holder.itemView.findViewById<TextView>(R.id.txtTime)

        txtContent.text = msg.content
        txtTime.text = formattedTime

        if (msg.isMe) {
            txtSender.visibility = View.GONE
            holder.itemView.findViewById<View>(R.id.bubbleContainer)?.setBackgroundResource(R.drawable.bubble_me)
        } else {
            txtSender.visibility = View.VISIBLE
            txtSender.text = msg.senderName
            holder.itemView.findViewById<View>(R.id.bubbleContainer)?.setBackgroundResource(R.drawable.bubble_other)
        }
    }

    override fun getItemCount(): Int = messages.size

    fun addMessage(msg: NetMessage) {
        messages.add(msg)
        notifyItemInserted(messages.size - 1)
    }

    class MeViewHolder(view: View) : RecyclerView.ViewHolder(view)
    class OtherViewHolder(view: View) : RecyclerView.ViewHolder(view)
}
