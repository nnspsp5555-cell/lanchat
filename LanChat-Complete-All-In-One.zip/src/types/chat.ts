export type DeviceType = 'android' | 'mobile' | 'desktop' | 'tablet';

export type UserStatus = 'online' | 'busy' | 'away';

export interface User {
  id: string;
  name: string;
  avatar: string;
  deviceType: DeviceType;
  status: UserStatus;
  ip?: string;
  joinedAt: number;
}

export type MediaType = 'text' | 'image' | 'video' | 'audio' | 'file';

export interface ReplyContext {
  id: string;
  senderName: string;
  content: string;
  mediaType?: MediaType;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  recipientId: 'public' | string; // 'public' or recipient's userId
  content: string;
  mediaType: MediaType;
  fileUrl?: string;
  fileName?: string;
  fileSize?: number;
  fileMime?: string;
  timestamp: number;
  replyTo?: ReplyContext;
}

export type ThemePreset = 'slate' | 'navy' | 'amoled' | 'emerald' | 'violet';
export type PatternStyle = 'none' | 'dots' | 'grid' | 'waves';
export type AccentColor = 'cyan' | 'emerald' | 'violet' | 'amber' | 'rose' | 'sky';
export type FontSize = 'sm' | 'md' | 'lg';

export interface ThemeSettings {
  preset: ThemePreset;
  pattern: PatternStyle;
  accent: AccentColor;
  fontSize: FontSize;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
}

export interface NetworkInfo {
  port: number;
  hostname: string;
  platform: string;
  localIps: { address: string; family: string; interfaceName: string }[];
  clientIp: string;
  uptimeSeconds: number;
  timestamp: number;
}
