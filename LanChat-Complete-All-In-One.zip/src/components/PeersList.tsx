import React, { useState, useEffect } from 'react';
import {
  Users,
  Smartphone,
  Laptop,
  Tablet,
  Radio,
  Search,
  Zap,
  MessageSquare,
  ShieldAlert,
  Radar,
  Loader2,
  Wifi,
} from 'lucide-react';
import { User, DeviceType, AccentColor } from '../types/chat';

interface PeersListProps {
  currentUser: User | null;
  peers: User[];
  activeChatId: string; // 'public' or userId
  onSelectChat: (chatId: string) => void;
  onSendNudge: (targetId: string) => void;
  unreadCounts: Record<string, number>;
  accent: AccentColor;
  onCloseMobileDrawer?: () => void;
}

export const PeersList: React.FC<PeersListProps> = ({
  currentUser,
  peers,
  activeChatId,
  onSelectChat,
  onSendNudge,
  unreadCounts,
  accent,
  onCloseMobileDrawer,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [networkDevices, setNetworkDevices] = useState<{ ip: string; mac: string; type: string }[]>([]);

  // Function to scan local router for connected devices immediately
  const scanRouterDevices = async () => {
    setIsScanning(true);
    try {
      const res = await fetch('/api/discover-devices');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.devices)) {
          setNetworkDevices(data.devices);
        }
      }
    } catch (e) {
      console.warn('Network discovery error:', e);
    } finally {
      setTimeout(() => setIsScanning(false), 800);
    }
  };

  useEffect(() => {
    scanRouterDevices();
  }, []);

  // Device icon resolver
  const renderDeviceIcon = (deviceType: DeviceType) => {
    switch (deviceType) {
      case 'android':
        return (
          <span title="هاتف أندرويد" className="inline-flex items-center">
            <Smartphone size={13} className="text-emerald-400" />
          </span>
        );
      case 'mobile':
        return (
          <span title="هاتف ذكي" className="inline-flex items-center">
            <Smartphone size={13} className="text-sky-400" />
          </span>
        );
      case 'tablet':
        return (
          <span title="جهاز لوحي" className="inline-flex items-center">
            <Tablet size={13} className="text-purple-400" />
          </span>
        );
      default:
        return (
          <span title="كمبيوتر / حاسوب" className="inline-flex items-center">
            <Laptop size={13} className="text-amber-400" />
          </span>
        );
    }
  };

  // Filter peers
  const otherPeers = peers.filter((p) => p.id !== currentUser?.id);
  const filteredPeers = otherPeers.filter((p) =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const activeItemBorder: Record<AccentColor, string> = {
    cyan: 'border-cyan-500 bg-cyan-500/10 text-cyan-300',
    emerald: 'border-emerald-500 bg-emerald-500/10 text-emerald-300',
    violet: 'border-violet-500 bg-violet-500/10 text-violet-300',
    amber: 'border-amber-500 bg-amber-500/10 text-amber-300',
    rose: 'border-rose-500 bg-rose-500/10 text-rose-300',
    sky: 'border-sky-500 bg-sky-500/10 text-sky-300',
  };

  const handleSelect = (id: string) => {
    onSelectChat(id);
    if (onCloseMobileDrawer) onCloseMobileDrawer();
  };

  return (
    <div className="flex flex-col h-full bg-slate-950/70 border-l border-slate-800/80 w-full select-none">
      {/* Header */}
      <div className="p-3 border-b border-slate-800/70">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <Radio size={16} className="text-emerald-400 animate-pulse" />
            <h2 className="font-bold text-sm text-slate-100">شبكة المحادثة المحلية</h2>
          </div>
          <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full font-mono">
            {peers.length} جهاز
          </span>
        </div>

        {/* Search & Radar Scan Row */}
        <div className="flex items-center gap-1.5">
          <div className="relative flex-1">
            <input
              type="text"
              placeholder="بحث عن جهاز..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1.5 pr-8 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
            <Search size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
          </div>

          <button
            onClick={scanRouterDevices}
            disabled={isScanning}
            className="p-2 rounded-xl bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-800/40 text-cyan-300 transition-colors cursor-pointer shrink-0"
            title="فحص أجهزة Wi-Fi على الراوتر فوراً (رادار)"
          >
            {isScanning ? (
              <Loader2 size={15} className="animate-spin text-cyan-400" />
            ) : (
              <Radar size={15} className="text-cyan-400" />
            )}
          </button>
        </div>
      </div>

      {/* Main List */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
        {/* Public Room Option */}
        <button
          onClick={() => handleSelect('public')}
          className={`w-full flex items-center justify-between p-2.5 rounded-xl border text-right transition-all cursor-pointer ${
            activeChatId === 'public'
              ? activeItemBorder[accent]
              : 'border-slate-800/70 bg-slate-900/40 hover:bg-slate-900 text-slate-200'
          }`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-500 flex items-center justify-center text-white shadow-md shrink-0">
              <Users size={20} />
            </div>
            <div className="min-w-0">
              <div className="font-bold text-xs truncate">الغرفة العامة (الجميع)</div>
              <div className="text-[11px] text-slate-400 flex items-center gap-1">
                <span>محادثة مفتوحة لجميع أجهزة الشبكة</span>
              </div>
            </div>
          </div>

          {/* Badges */}
          <div className="flex items-center gap-1.5">
            {unreadCounts['public'] ? (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500 text-slate-950">
                {unreadCounts['public']}
              </span>
            ) : null}
          </div>
        </button>

        {/* Section title */}
        <div className="pt-2 px-1 text-[11px] font-semibold text-slate-400 flex items-center justify-between">
          <span>المحادثات الخاصة ({otherPeers.length})</span>
        </div>

        {/* Peers list */}
        {filteredPeers.length === 0 ? (
          <div className="text-center py-6 px-3 text-slate-500 text-xs">
            {searchTerm ? (
              'لا يوجد متصل يطابق البحث'
            ) : (
              <div className="space-y-1">
                <p>لا توجد أجهزة أخرى متصلة حالياً.</p>
                <p className="text-[10px] text-slate-400">
                  وصّل هاتف أندرويد آخر بنفس شبكة الـ Wi-Fi وافتح الرابط!
                </p>
              </div>
            )}
          </div>
        ) : (
          filteredPeers.map((peer) => {
            const isActive = activeChatId === peer.id;
            const unread = unreadCounts[peer.id] || 0;

            return (
              <div
                key={peer.id}
                className={`group flex items-center justify-between p-2 rounded-xl border text-right transition-all ${
                  isActive
                    ? activeItemBorder[accent]
                    : 'border-slate-800/60 bg-slate-900/30 hover:bg-slate-900/80 text-slate-200'
                }`}
              >
                {/* Peer trigger */}
                <button
                  onClick={() => handleSelect(peer.id)}
                  className="flex items-center gap-2.5 min-w-0 flex-1 text-right cursor-pointer"
                >
                  <div className="relative shrink-0">
                    <div className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-sm font-bold shadow-sm">
                      {peer.avatar || '👤'}
                    </div>
                    {/* Online green indicator */}
                    <span className="absolute bottom-0 left-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-slate-950" />
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="font-semibold text-xs truncate flex items-center gap-1.5">
                      <span className="truncate">{peer.name}</span>
                      {renderDeviceIcon(peer.deviceType)}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                      <span>{peer.ip || 'Wi-Fi Peer'}</span>
                    </div>
                  </div>
                </button>

                {/* Actions */}
                <div className="flex items-center gap-1">
                  {unread > 0 && (
                    <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500 text-slate-950">
                      {unread}
                    </span>
                  )}

                  {/* Nudge / Buzz button */}
                  <button
                    onClick={() => onSendNudge(peer.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 transition-colors opacity-80 group-hover:opacity-100 cursor-pointer"
                    title={`إرسال تنبيه اهتزاز إلى ${peer.name}`}
                  >
                    <Zap size={14} />
                  </button>
                </div>
              </div>
            );
          })
        )}

        {/* Router Discovered Wi-Fi Devices */}
        {networkDevices.length > 0 && (
          <div className="pt-3 border-t border-slate-800/80">
            <div className="px-1 text-[11px] font-semibold text-emerald-400 flex items-center justify-between mb-1.5">
              <span className="flex items-center gap-1">
                <Wifi size={12} />
                <span>أجهزة نشطة على الراوتر ({networkDevices.length})</span>
              </span>
            </div>

            <div className="space-y-1">
              {networkDevices.map((nd) => (
                <div
                  key={nd.ip}
                  className="p-2 rounded-xl bg-slate-900/40 border border-slate-800/50 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2">
                    <Smartphone size={14} className="text-emerald-400" />
                    <div>
                      <div className="font-mono text-[11px] text-slate-200">{nd.ip}</div>
                      <div className="text-[9px] text-slate-500 font-mono">{nd.mac}</div>
                    </div>
                  </div>
                  <span className="text-[10px] text-emerald-400/90 bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-800/30">
                    متصل
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Self Profile Strip at bottom of sidebar */}
      {currentUser && (
        <div className="p-2.5 border-t border-slate-800/80 bg-slate-900/50 flex items-center justify-between">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-full bg-cyan-600/30 border border-cyan-500/40 text-cyan-300 flex items-center justify-center text-xs font-bold shrink-0">
              {currentUser.avatar}
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold text-slate-200 truncate flex items-center gap-1">
                <span>{currentUser.name}</span>
                <span className="text-[10px] text-cyan-400">(أنت)</span>
              </div>
              <div className="text-[10px] text-slate-400 font-mono truncate">
                {currentUser.ip || 'متصل محلياً'}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
