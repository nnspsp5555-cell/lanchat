package com.example.lanchat

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputFilter
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: MessageAdapter
    private lateinit var list: RecyclerView
    private lateinit var online: TextView
    private lateinit var status: TextView
    private lateinit var callBar: TextView
    private val callListener: () -> Unit = { updateCallBar() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        list = findViewById(R.id.list)
        online = findViewById(R.id.online)
        status = findViewById(R.id.status)
        callBar = findViewById(R.id.callBar)
        findViewById<Button>(R.id.callBtn).setOnClickListener { onCallClick() }
        callBar.setOnClickListener { openCallScreen() }
        val input = findViewById<EditText>(R.id.input)
        val send = findViewById<Button>(R.id.send)

        input.filters = arrayOf(InputFilter.LengthFilter(ChatNet.MAX_LEN))

        adapter = MessageAdapter(ChatNet.messages)
        list.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        list.adapter = adapter

        ChatNet.onMessage = {
            adapter.notifyItemInserted(ChatNet.messages.size - 1)
            list.scrollToPosition(ChatNet.messages.size - 1)
        }
        ChatNet.onPeers = { names ->
            online.text = if (names.isEmpty()) {
                "لا يوجد أحد متصل بعد"
            } else {
                "🟢 ${names.size} متصل: ${names.joinToString("، ")}"
            }
        }
        ChatNet.onStatus = { msg ->
            status.text = msg ?: ""
            status.visibility = if (msg == null) TextView.GONE else TextView.VISIBLE
        }

        send.setOnClickListener {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) {
                ChatNet.send(t)
                input.setText("")
            }
        }

        ensureName()
    }

    override fun onStart() {
        super.onStart()
        ChatNet.appVisible = true
        CallManager.addListener(callListener)
        updateCallBar()
        adapter.notifyDataSetChanged()
        if (ChatNet.messages.isNotEmpty()) list.scrollToPosition(ChatNet.messages.size - 1)
    }

    override fun onStop() {
        ChatNet.appVisible = false
        CallManager.removeListener(callListener)
        super.onStop()
    }

    private fun openCallScreen() {
        startActivity(Intent(this, CallActivity::class.java))
    }

    private fun updateCallBar() {
        val n = CallManager.peerName
        val t = when (CallManager.state) {
            CallManager.State.IDLE -> null
            CallManager.State.INCOMING -> "📞 مكالمة واردة من $n — اضغط للرد"
            CallManager.State.OUTGOING -> "📞 جاري الاتصال بـ $n — اضغط للعودة"
            CallManager.State.ACTIVE -> "🟢 مكالمة جارية مع $n — اضغط للعودة"
        }
        callBar.text = t ?: ""
        callBar.visibility = if (t == null) View.GONE else View.VISIBLE
    }

    private fun onCallClick() {
        if (CallManager.state != CallManager.State.IDLE) {
            openCallScreen()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            return
        }
        val peers = ChatNet.peerList()
        if (peers.isEmpty()) {
            Toast.makeText(this, "لا يوجد أحد متصل حالياً", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("اتصل بمن؟")
            .setItems(peers.map { it.name }.toTypedArray()) { _, which ->
                CallManager.call(this, peers[which])
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 2) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                onCallClick()
            } else {
                Toast.makeText(this, "لازم تسمح للميكروفون حتى تتصل", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun ensureName() {
        val prefs = getSharedPreferences("lanchat", MODE_PRIVATE)
        val saved = prefs.getString("name", "") ?: ""
        if (saved.isNotBlank()) {
            begin(saved)
            return
        }
        val box = EditText(this).apply {
            hint = "اكتب اسمك"
            filters = arrayOf(InputFilter.LengthFilter(24))
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("مرحباً 👋")
            .setMessage("اختر اسماً يظهر للآخرين")
            .setView(box)
            .setCancelable(false)
            .setPositiveButton("دخول") { _, _ ->
                val n = box.text.toString().trim().ifEmpty { "مستخدم" + (100..999).random() }
                prefs.edit().putString("name", n).apply()
                begin(n)
            }
            .show()
    }

    private fun begin(name: String) {
        ChatNet.myName = name

        // إذن الإشعارات (أندرويد 13 وما فوق)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        // الخدمة تبقي الدردشة شغّالة بالخلفية وترسل الإشعارات
        ContextCompat.startForegroundService(this, Intent(this, ChatService::class.java))

        askBatteryOnce()
    }

    /** مرة وحدة: نطلب إيقاف تحسين البطارية حتى ما يقفل النظام التطبيق */
    private fun askBatteryOnce() {
        val prefs = getSharedPreferences("lanchat", MODE_PRIVATE)
        if (prefs.getBoolean("battery_asked", false)) return
        val pm = getSystemService(PowerManager::class.java)
        if (pm != null && pm.isIgnoringBatteryOptimizations(packageName)) return
        prefs.edit().putBoolean("battery_asked", true).apply()
        AlertDialog.Builder(this)
            .setTitle("حتى توصلك الرسائل")
            .setMessage("اسمح للتطبيق يشتغل بالخلفية بدون قيود البطارية، وإلا ممكن النظام يوقفه وتفوتك الرسائل.")
            .setPositiveButton("سماح") { _, _ ->
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                            .setData(Uri.parse("package:$packageName"))
                    )
                } catch (_: Exception) {
                }
            }
            .setNegativeButton("لاحقاً", null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        ChatNet.onMessage = null
        ChatNet.onPeers = null
        ChatNet.onStatus = null
    }
}
