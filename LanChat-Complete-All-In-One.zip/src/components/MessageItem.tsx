import React from 'react';
import { Reply, Copy, Check, FileText, Download, CornerUpLeft } from 'lucide-react';
import { ChatMessage, AccentColor } from '../types/chat';
import { formatFileSize } from '../utils/media';
import { AudioPlayer } from './AudioPlayer';

interface MessageItemProps {
  message: ChatMessage;
  isSelf: boolean;
  accent: AccentColor;
  onReply: (msg: ChatMessage) => void;
  onOpenImage: (url: string, fileName?: string) => void;
}

export const MessageItem: React.FC<MessageItemProps> = ({
  message,
  isSelf,
  accent,
  onReply,
  onOpenImage,
}) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    if (message.content) {
      navigator.clipboard.writeText(message.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const formattedTime = new Date(message.timestamp).toLocaleTimeString('ar-SA', {
    hour: '2-digit',
    minute: '2-digit',
  });

  // Dynamic bubble styling based on accent and sender
  const selfBubbleClasses: Record<AccentColor, string> = {
    cyan: 'bg-cyan-600 text-white rounded-tr-sm shadow-cyan-950/40',
    emerald: 'bg-emerald-600 text-white rounded-tr-sm shadow-emerald-950/40',
    violet: 'bg-violet-600 text-white rounded-tr-sm shadow-violet-950/40',
    amber: 'bg-amber-600 text-white rounded-tr-sm shadow-amber-950/40',
    rose: 'bg-rose-600 text-white rounded-tr-sm shadow-rose-950/40',
    sky: 'bg-sky-600 text-white rounded-tr-sm shadow-sky-950/40',
  };

  const peerBubbleClass = 'bg-slate-800/90 text-slate-100 rounded-tl-sm border border-slate-700/50 shadow-black/20';

  return (
    <div
      className={`group flex items-end gap-2 w-full my-1.5 transition-all ${
        isSelf ? 'justify-start flex-row-reverse' : 'justify-start'
      }`}
    >
      {/* Avatar for peer */}
      {!isSelf && (
        <div
          className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-sm font-bold shrink-0 select-none shadow-sm"
          title={message.senderName}
        >
          {message.senderAvatar || '👤'}
        </div>
      )}

      {/* Message Bubble Container */}
      <div
        className={`relative max-w-[85%] sm:max-w-[70%] rounded-2xl p-3 shadow-md transition-all ${
          isSelf ? selfBubbleClasses[accent] : peerBubbleClass
        }`}
      >
        {/* Peer name header in public room */}
        {!isSelf && message.recipientId === 'public' && (
          <div className="text-xs font-bold text-cyan-400 mb-1 flex items-center gap-1">
            <span>{message.senderName}</span>
          </div>
        )}

        {/* Reply Quote Banner */}
        {message.replyTo && (
          <div
            className={`mb-2 p-2 rounded-lg text-xs border-r-4 flex flex-col gap-0.5 ${
              isSelf
                ? 'bg-black/20 border-white/60 text-slate-100'
                : 'bg-slate-900/60 border-cyan-500 text-slate-300'
            }`}
          >
            <div className="font-semibold flex items-center gap-1 opacity-90">
              <CornerUpLeft size={12} />
              <span>{message.replyTo.senderName}</span>
            </div>
            <div className="truncate opacity-80">{message.replyTo.content || '[مرفق]'}</div>
          </div>
        )}

        {/* Media: Image */}
        {message.mediaType === 'image' && message.fileUrl && (
          <div className="mb-2 overflow-hidden rounded-xl bg-black/30">
            <img
              src={message.fileUrl}
              alt={message.fileName || 'صورة مرسلة'}
              onClick={() => onOpenImage(message.fileUrl!, message.fileName)}
              className="max-h-80 w-auto rounded-xl object-contain cursor-pointer hover:opacity-95 transition-opacity"
              loading="lazy"
            />
          </div>
        )}

        {/* Media: Video */}
        {message.mediaType === 'video' && message.fileUrl && (
          <div className="mb-2 overflow-hidden rounded-xl bg-black/40">
            <video
              src={message.fileUrl}
              controls
              playsInline
              preload="metadata"
              className="max-h-72 w-full rounded-xl bg-black"
            />
          </div>
        )}

        {/* Media: Audio / Voice note */}
        {message.mediaType === 'audio' && message.fileUrl && (
          <div className="mb-2">
            <AudioPlayer src={message.fileUrl} fileName={message.fileName} accentColor={accent} />
          </div>
        )}

        {/* Media: Generic File / Document / APK */}
        {message.mediaType === 'file' && message.fileUrl && (
          <div
            className={`mb-2 flex items-center justify-between gap-3 p-2.5 rounded-xl border ${
              isSelf
                ? 'bg-black/25 border-white/20'
                : 'bg-slate-900/70 border-slate-700/80'
            }`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-lg bg-cyan-500/20 text-cyan-300 flex items-center justify-center shrink-0">
                <FileText size={20} />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-medium truncate max-w-[170px] sm:max-w-[240px]">
                  {message.fileName || 'ملف مرفق'}
                </p>
                <p className="text-[10px] opacity-75">{formatFileSize(message.fileSize)}</p>
              </div>
            </div>

            <a
              href={message.fileUrl}
              download={message.fileName || 'file'}
              className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors shrink-0"
              title="تنزيل الملف"
            >
              <Download size={16} />
            </a>
          </div>
        )}

        {/* Text Content */}
        {message.content && (
          <p className="text-sm whitespace-pre-wrap break-words leading-relaxed select-text dir-rtl">
            {message.content}
          </p>
        )}

        {/* Metadata Footer: Timestamp & Checkmarks */}
        <div
          className={`flex items-center gap-1.5 mt-1 text-[10px] ${
            isSelf ? 'justify-start text-white/80' : 'justify-end text-slate-400'
          }`}
        >
          <span className="font-mono">{formattedTime}</span>
          {isSelf && <Check size={12} className="text-cyan-200 stroke-[3]" />}
        </div>

        {/* Hover/Touch Quick Action Bar */}
        <div
          className={`absolute top-0 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-full px-1.5 py-0.5 shadow-lg z-20 ${
            isSelf ? 'left-2' : 'right-2'
          }`}
        >
          <button
            onClick={() => onReply(message)}
            className="p-1 text-slate-300 hover:text-cyan-400 transition-colors"
            title="رد"
          >
            <Reply size={13} />
          </button>
          {message.content && (
            <button
              onClick={handleCopy}
              className="p-1 text-slate-300 hover:text-emerald-400 transition-colors"
              title={copied ? 'تم النسخ!' : 'نسخ النص'}
            >
              {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
