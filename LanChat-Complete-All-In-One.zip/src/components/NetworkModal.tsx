import React, { useEffect, useState } from 'react';
import {
  X,
  Wifi,
  QrCode,
  Copy,
  Check,
  Smartphone,
  Server,
  Activity,
  Info,
  ExternalLink,
  RefreshCw,
  Share2,
  Download,
} from 'lucide-react';
import QRCode from 'qrcode';
import { NetworkInfo } from '../types/chat';

interface NetworkModalProps {
  isOpen: boolean;
  onClose: () => void;
  networkInfo: NetworkInfo | null;
  onRefreshNetwork: () => void;
}

export const NetworkModal: React.FC<NetworkModalProps> = ({
  isOpen,
  onClose,
  networkInfo,
  onRefreshNetwork,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const [selectedIpIndex, setSelectedIpIndex] = useState(0);
  const [pingLatency, setPingLatency] = useState<number | null>(null);
  const [isPinging, setIsPinging] = useState(false);

  // Check if we are running on a cloud/web domain or local machine
  const isWebEnvironment = typeof window !== 'undefined' && 
    (window.location.protocol === 'https:' || (!['localhost', '127.0.0.1'].includes(window.location.hostname) && !window.location.hostname.startsWith('192.168.')));

  // Compute active connection URL
  const localIp = networkInfo?.localIps?.[selectedIpIndex]?.address || window.location.hostname;
  const localPort = networkInfo?.port || window.location.port || 3000;
  
  // If hosted online, prioritize the actual origin so sending it to friends works immediately!
  const fullUrl = isWebEnvironment ? window.location.origin : `http://${localIp}:${localPort}`;

  // Generate QR code when URL changes
  useEffect(() => {
    if (!isOpen) return;

    QRCode.toDataURL(fullUrl, {
      width: 240,
      margin: 1.5,
      color: {
        dark: '#080c14',
        light: '#ffffff',
      },
    })
      .then((url) => setQrDataUrl(url))
      .catch((err) => console.error('QR generation error:', err));
  }, [fullUrl, isOpen]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedUrl(text);
    setTimeout(() => setCopiedUrl(null), 2000);
  };

  const shareViaWebShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'الدردشة بدون إنترنت',
          text: 'انضم إلي الآن في غرفة الدردشة عبر الرابط:',
          url: fullUrl,
        });
      } catch {}
    } else {
      copyToClipboard(fullUrl);
    }
  };

  const testPing = async () => {
    setIsPinging(true);
    const start = performance.now();
    try {
      await fetch('/api/network-info?t=' + Date.now());
      const diff = Math.round(performance.now() - start);
      setPingLatency(diff);
    } catch {
      setPingLatency(-1);
    } finally {
      setIsPinging(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-xl max-h-[90vh] overflow-y-auto shadow-2xl p-4 sm:p-6 flex flex-col gap-5 text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400">
              <Wifi size={22} />
            </div>
            <div>
              <h2 className="font-bold text-base sm:text-lg">ربط أجهزة أندرويد عبر Wi-Fi</h2>
              <p className="text-xs text-slate-400">مراسلة محلية 100% بدون الحاجة لإنترنت</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* QR Code and Direct URL Section */}
        <div className="flex flex-col sm:flex-row items-center gap-5 bg-slate-950/70 border border-slate-800 rounded-2xl p-4">
          {/* QR Code display */}
          <div className="bg-white p-2.5 rounded-2xl shadow-xl shrink-0 flex flex-col items-center">
            {qrDataUrl ? (
              <img src={qrDataUrl} alt="رمز الاستجابة السريعة QR" className="w-40 h-40 sm:w-44 sm:h-44 rounded-xl" />
            ) : (
              <div className="w-40 h-40 flex items-center justify-center text-slate-400 text-xs">
                جاري توليد الرمز...
              </div>
            )}
            <span className="text-[10px] text-slate-700 font-bold mt-1">امسح بكاميرا الهاتف</span>
          </div>

          {/* Connection URL Details */}
          <div className="flex-1 flex flex-col gap-3 w-full">
            <div>
              <span className="text-xs font-semibold text-cyan-400 block mb-1">
                رابط الاتصال المباشر للأجهزة:
              </span>
              <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl p-2.5">
                <span className="font-mono text-xs sm:text-sm text-slate-200 select-all truncate flex-1 dir-ltr text-left">
                  {fullUrl}
                </span>
                <button
                  onClick={shareViaWebShare}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 transition-colors cursor-pointer shrink-0"
                  title="مشاركة الرابط"
                >
                  <Share2 size={16} />
                </button>
                <button
                  onClick={() => copyToClipboard(fullUrl)}
                  className="p-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white transition-colors cursor-pointer shrink-0"
                  title="نسخ الرابط"
                >
                  {copiedUrl === fullUrl ? <Check size={16} /> : <Copy size={16} />}
                </button>
              </div>
            </div>

            {/* If machine has multiple IPs (e.g. WiFi vs Ethernet) */}
            {networkInfo && networkInfo.localIps.length > 1 && (
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">
                  اختر بطاقة الشبكة (IP):
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {networkInfo.localIps.map((ip, idx) => (
                    <button
                      key={ip.address}
                      onClick={() => setSelectedIpIndex(idx)}
                      className={`px-2 py-1 rounded-lg text-xs font-mono transition-all cursor-pointer ${
                        selectedIpIndex === idx
                          ? 'bg-cyan-500 text-slate-950 font-bold'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {ip.address} ({ip.interfaceName})
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Network diagnostic status */}
            <div className="flex items-center justify-between text-xs bg-slate-900/60 p-2 rounded-xl">
              <div className="flex items-center gap-1.5 text-slate-400">
                <Activity size={14} className="text-emerald-400" />
                <span>زمن الاستجابة:</span>
                <span className="font-mono text-slate-200">
                  {pingLatency !== null ? `${pingLatency} ms` : '--'}
                </span>
              </div>
              <button
                onClick={testPing}
                disabled={isPinging}
                className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-[11px] text-cyan-400 transition-colors cursor-pointer"
              >
                {isPinging ? 'جاري الفحص...' : 'فحص الاتصال'}
              </button>
            </div>
          </div>
        </div>

        {/* Step-by-Step Offline Wi-Fi Guide */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
            <Smartphone size={16} className="text-cyan-400" />
            <span>كيف تتواصل بدون إنترنت خطوة بخطوة؟</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
            <div className="bg-slate-950/60 border border-slate-800/80 p-3 rounded-2xl flex flex-col gap-1.5">
              <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 text-xs font-bold flex items-center justify-center">
                1
              </span>
              <strong className="text-slate-100">شبكة Wi-Fi أو Hotspot</strong>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                شغّل نقطة اتصال (Hotspot) من هاتف أندرويد، أو اتصل براوتر منزلي (لا تشترط باقة إنترنت أو خط هاتف).
              </p>
            </div>

            <div className="bg-slate-950/60 border border-slate-800/80 p-3 rounded-2xl flex flex-col gap-1.5">
              <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 text-xs font-bold flex items-center justify-center">
                2
              </span>
              <strong className="text-slate-100">تشغيل الخادم</strong>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                يجب أن يعمل الخادم على جهاز واحد (حاسوب محمول، كمبيوتر، أو هاتف عبر تطبيق Termux) داخل الشبكة.
              </p>
            </div>

            <div className="bg-slate-950/60 border border-slate-800/80 p-3 rounded-2xl flex flex-col gap-1.5">
              <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 text-xs font-bold flex items-center justify-center">
                3
              </span>
              <strong className="text-slate-100">فتح الرابط بالمتصفح</strong>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                امسح رمز الـ QR بكاميرا هاتف أندرويد وافتح الرابط في Chrome فوراً لبدء المحادثة بدون أي تثبيت خارجي!
              </p>
            </div>
          </div>
        </div>

        {/* Technical Notice on APK & Offline PWA */}
        <div className="bg-cyan-950/30 border border-cyan-800/40 rounded-2xl p-3 flex items-start gap-2.5 text-xs text-cyan-200">
          <Info size={18} className="shrink-0 mt-0.5 text-cyan-400" />
          <div className="leading-relaxed">
            <span className="font-bold block text-cyan-300">ملاحظة بشأن تطبيق أندرويد (PWA):</span>
            يعمل هذا التطبيق بنظام الويب التقدمي (PWA) داخل المتصفح مباشرة. يمكنك النقر على خيارات المتصفح (⋮) ثم اختيار <strong>«إضافة إلى الشاشة الرئيسية»</strong> ليصبح تطبيقاً مستقلاً بأيقونة خاصة على هاتفك دون الحاجة لملف APK خارجي.
          </div>
        </div>

        {/* Native Android LanChat Studio Source Code */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-3.5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 shrink-0">
              <Smartphone size={22} />
            </div>
            <div>
              <span className="font-bold text-xs text-slate-100 block">مشروع أندرويد ستوديو الأصلي (LanChat)</span>
              <span className="text-[11px] text-slate-400 block">
                كود Kotlin كامل يبحث عن أجهزة Wi-Fi تلقائياً ببروتوكول UDP Broadcast فور فتح التطبيق.
              </span>
            </div>
          </div>

          <a
            href="/api/download-android-zip"
            download="LanChat-Android-Project.zip"
            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shrink-0 shadow-lg cursor-pointer"
          >
            <Download size={15} />
            <span>تحميل المشروع (ZIP)</span>
          </a>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs text-slate-400">
          <button
            onClick={onRefreshNetwork}
            className="flex items-center gap-1.5 hover:text-cyan-400 transition-colors cursor-pointer"
          >
            <RefreshCw size={14} />
            <span>تحديث معلومات الشبكة</span>
          </button>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
